import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Menu, X, ChevronDown, LogOut, User, Settings,
  LayoutDashboard
} from 'lucide-react';
import ThemeToggle from '../shared/ThemeToggle';
import GlobalSearchBar from '../shared/GlobalSearchBar';
import NotifBell from '../shared/NotifBell';
import BrandLogo from '../shared/BrandLogo';
import Avatar from '../ui/Avatar';
import useAuth from '../../hooks/useAuth';
import toast from 'react-hot-toast';

const Logo = () => <BrandLogo asLink size="sm" className="hover-lift" />;

const UserDropdown = ({ user, onLogout }) => {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e) => { if (!ref.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const roleColors = {
    student: 'text-[var(--role-cyan)]',
    coordinator: 'text-[var(--role-gold)]',
    alumni: 'text-[var(--role-coral)]',
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-2 py-1.5 rounded-xl hover:bg-[var(--color-border)] hover-lift transition-colors"
      >
        <Avatar name={user.name} size="sm" src={user.profilePic} />
        <div className="hidden md:flex flex-col items-start">
          <span className="text-sm font-semibold text-[var(--color-text-primary)] leading-none">{user.name}</span>
          <span className={`text-xs capitalize ${roleColors[user.role] || 'text-primary-400'}`}>{user.role}</span>
        </div>
        <ChevronDown size={14} className={`text-[var(--color-text-muted)] transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-52 card p-1.5 z-50 animate-slide-down shadow-[0_24px_56px_-42px_rgba(0,0,0,.7)]">
          <div className="px-3 py-2 border-b border-[var(--color-border)] mb-1">
            <p className="text-sm font-semibold text-[var(--color-text-primary)] truncate">{user.name}</p>
            <p className="text-xs text-[var(--color-text-muted)] truncate">{user.email}</p>
          </div>
          {[
            { icon: LayoutDashboard, label: 'Dashboard', to: `/${user.role}/dashboard` },
            { icon: User, label: 'Profile', to: '/profile' },
            { icon: Settings, label: 'Settings', to: '/settings' },
          ].map(({ icon: Icon, label, to }) => (
            <button
              key={label}
              onClick={() => { navigate(to); setOpen(false); }}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-[var(--color-text-secondary)] hover:bg-[var(--color-border)] hover:text-[var(--color-text-primary)] transition-colors"
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
          <div className="border-t border-[var(--color-border)] mt-1 pt-1">
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-[var(--role-coral)] hover:bg-[var(--role-coral-tint)] transition-colors"
            >
              <LogOut size={15} />
              Sign Out
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const Navbar = ({ onMenuToggle, menuOpen }) => {
  const { user, isAuthenticated, logoutUser } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logoutUser();
    toast.success('Signed out successfully');
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--color-border)] glass">
      <div className="flex items-center justify-between h-16 px-4 md:px-6 max-w-screen-2xl mx-auto">
        <div className="flex items-center gap-3">
          {isAuthenticated && (
            <button
              onClick={onMenuToggle}
              className="lg:hidden w-10 h-10 rounded-xl flex items-center justify-center hover:bg-[var(--color-border)] transition-colors text-[var(--color-text-secondary)]"
            >
              {menuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          )}
          <Logo />
        </div>

        {/* ✅ GlobalSearchBar added here — visible only when authenticated */}
        {isAuthenticated && <GlobalSearchBar />}

        <div className="flex items-center gap-1">
          <ThemeToggle />
          {isAuthenticated ? (
            <>
              <NotifBell />
              <div className="w-px h-6 bg-[var(--color-border)] mx-1" />
              <UserDropdown user={user} onLogout={handleLogout} />
            </>
          ) : (
            <div className="flex items-center gap-2 ml-2">
              <Link to="/login" className="text-sm font-semibold text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] px-4 py-2 rounded-xl hover:bg-[var(--color-border)] transition-colors">
                Sign In
              </Link>
              <Link to="/register" className="text-sm font-semibold bg-[linear-gradient(120deg,var(--role-cyan),var(--role-gold),var(--role-magenta))] hover:brightness-105 text-[var(--text-reverse)] px-4 py-2 rounded-xl transition-all shadow-[0_10px_28px_rgba(249,200,14,.26),0_6px_20px_rgba(255,99,146,.2)]">
                Get Started
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;