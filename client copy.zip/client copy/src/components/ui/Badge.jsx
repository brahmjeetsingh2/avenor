import React from 'react';

const variants = {
  primary:   'bg-[var(--role-cyan-tint)] text-[var(--role-cyan)] border-[rgba(90,169,230,0.22)]',
  accent:    'bg-[var(--role-magenta-tint)] text-[var(--role-magenta)] border-[rgba(255,99,146,0.22)]',
  success:   'bg-[var(--role-coral-tint)] text-[var(--role-coral)] border-[rgba(255, 99, 146, 0.22)]',
  warning:   'bg-[var(--role-gold-tint)] text-[var(--role-gold)] border-[rgba(249,200,14,0.22)]',
  danger:    'bg-[var(--role-coral-tint)] text-[var(--role-coral)] border-[rgba(248,102,36,0.22)]',
  ghost:     'bg-[var(--color-border)] text-[var(--color-text-secondary)] border-transparent',
  announced: 'bg-[var(--role-cyan-tint)] text-[var(--role-cyan)] border-[rgba(90,169,230,0.22)]',
  ppt:       'bg-[var(--role-magenta-tint)] text-[var(--role-magenta)] border-[rgba(255,99,146,0.22)]',
  test:      'bg-[var(--role-gold-tint)] text-[var(--role-gold)] border-[rgba(249,200,14,0.22)]',
  interview: 'bg-[var(--role-coral-tint)] text-[var(--role-coral)] border-[rgba(248,102,36,0.22)]',
  offer:     'bg-[var(--role-coral-tint)] text-[var(--role-coral)] border-[rgba(255, 99, 146, 0.22)]',
  closed:    'bg-[var(--color-border)] text-[var(--color-text-muted)] border-transparent',
};

const sizes = {
  xs: 'text-[10px] px-2 py-0.5 rounded-md',
  sm: 'text-xs px-2.5 py-0.5 rounded-lg',
  md: 'text-xs px-3 py-1 rounded-lg',
};

const Badge = ({
  children,
  variant = 'ghost',
  size = 'sm',
  dot = false,
  className = '',
}) => {
  return (
    <span
      className={`
        inline-flex items-center gap-1.5 font-semibold border
        ${variants[variant] || variants.ghost}
        ${sizes[size]}
        ${className}
      `}
    >
      {dot && (
        <span
          className={`w-1.5 h-1.5 rounded-full ${
            variant === 'success' ? 'bg-[var(--role-coral)]' :
            variant === 'danger'  ? 'bg-[var(--role-coral)]'  :
            variant === 'warning' ? 'bg-[var(--role-gold)]' :
            'bg-[var(--role-cyan)]'
          } animate-pulse`}
        />
      )}
      {children}
    </span>
  );
};

export default Badge;
