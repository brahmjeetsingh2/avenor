import React from 'react';
import Spinner from './Spinner';

const variants = {
  primary:
    'bg-[linear-gradient(120deg,var(--role-cyan),var(--role-gold))] hover:brightness-[1.03] text-[var(--text-reverse)] border-transparent shadow-[var(--btn-shadow-cyan)] hover:shadow-[var(--btn-shadow-gold)]',
  secondary:
    'bg-transparent border-[1.5px] border-[var(--color-border)] text-[var(--color-text-secondary)] hover:border-[var(--role-gold)] hover:text-[var(--role-gold)] hover:bg-[var(--role-gold-tint)]',
  ghost:
    'bg-transparent border-transparent text-[var(--role-cyan)] hover:bg-[var(--role-cyan-tint)] hover:text-[var(--role-cyan-deep)]',
  danger:
    'bg-[var(--role-coral)] hover:bg-[var(--role-coral-deep)] text-[var(--text-reverse)] border-transparent shadow-[var(--btn-shadow-coral)]',
  accent:
    'bg-[var(--role-magenta)] hover:bg-[var(--role-magenta-deep)] text-[var(--text-reverse)] border-transparent shadow-[var(--btn-shadow-magenta)]',
  success:
    'bg-[var(--role-coral)] hover:bg-[var(--role-coral-deep)] text-[var(--text-reverse)] border-transparent shadow-[var(--btn-shadow-coral)]',
  pro:
    'bg-[linear-gradient(90deg,var(--gradient-pro-start),var(--gradient-pro-end))] text-[var(--text-reverse)] border-transparent shadow-[var(--btn-shadow-gold)]',
};

const sizes = {
  xs: 'px-2.5 py-1 text-xs rounded-lg',
  sm: 'px-3.5 py-1.5 text-sm rounded-xl',
  md: 'px-5 py-2.5 text-sm rounded-xl',
  lg: 'px-6 py-3 text-base rounded-xl',
  xl: 'px-8 py-4 text-lg rounded-2xl',
};

const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  leftIcon,
  rightIcon,
  fullWidth = false,
  className = '',
  onClick,
  type = 'button',
  ...props
}) => {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={`
        inline-flex items-center justify-center gap-2 font-semibold
        border transition-all duration-200 cursor-pointer hover-lift
        disabled:opacity-50 disabled:cursor-not-allowed
        active:scale-[0.97] select-none
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--role-cyan)]/35 focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg)]
        ${variants[variant]}
        ${sizes[size]}
        ${fullWidth ? 'w-full' : ''}
        ${className}
      `}
      {...props}
    >
      {loading ? (
        <Spinner size="sm" className="text-current" />
      ) : leftIcon ? (
        <span className="shrink-0">{leftIcon}</span>
      ) : null}
      {children}
      {rightIcon && !loading && <span className="shrink-0">{rightIcon}</span>}
    </button>
  );
};

export default Button;
