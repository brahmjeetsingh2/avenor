import React from 'react';
import { Link } from 'react-router-dom';

const sizeMap = {
  xs: { mark: 'w-7 h-7 rounded-lg', text: 'text-sm', ring: 'inset-[3px]', spark: 'w-1.5 h-1.5' },
  sm: { mark: 'w-9 h-9 rounded-xl', text: 'text-lg', ring: 'inset-[4px]', spark: 'w-1.5 h-1.5' },
  md: { mark: 'w-11 h-11 rounded-2xl', text: 'text-xl', ring: 'inset-[5px]', spark: 'w-2 h-2' },
  lg: { mark: 'w-14 h-14 rounded-2xl', text: 'text-2xl', ring: 'inset-[6px]', spark: 'w-2.5 h-2.5' },
};

const BrandMark = ({ size = 'sm', className = '' }) => {
  const cfg = sizeMap[size] || sizeMap.sm;

  return (
    <div className={`relative ${cfg.mark} ${className}`}>
      <div className="absolute inset-0 rounded-[inherit] bg-[linear-gradient(135deg,var(--role-cyan)_8%,var(--role-gold)_58%,var(--role-magenta)_100%)] shadow-[0_18px_34px_-24px_rgba(249,200,14,.85)]" />
      <div className={`absolute ${cfg.ring} rounded-[inherit] border border-white/35`} />
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="font-display text-white font-bold tracking-[-0.04em] text-[0.58em]">HT</span>
      </div>
      <span className={`absolute -right-0.5 -top-0.5 ${cfg.spark} rounded-full bg-[var(--role-gold)] border border-white/70`} />
    </div>
  );
};

const BrandText = ({ size = 'sm' }) => {
  const cfg = sizeMap[size] || sizeMap.sm;
  return (
    <span className={`font-display font-bold ${cfg.text} leading-none tracking-[-0.03em] text-[var(--color-text-primary)]`}>
      Hire
      <span className="ml-0.5 text-transparent bg-clip-text bg-[linear-gradient(135deg,var(--role-cyan),var(--role-gold),var(--role-magenta))]">Track</span>
    </span>
  );
};

const BrandLogo = ({
  size = 'sm',
  showText = true,
  asLink = false,
  to = '/',
  className = '',
  onClick,
}) => {
  const content = (
    <>
      <BrandMark size={size} />
      {showText && <BrandText size={size} />}
    </>
  );

  const common = `inline-flex items-center gap-2.5 group select-none ${className}`;

  if (asLink) {
    return (
      <Link to={to} className={common} onClick={onClick}>
        {content}
      </Link>
    );
  }

  return (
    <div className={common} onClick={onClick}>
      {content}
    </div>
  );
};

export default BrandLogo;
export { BrandMark };
