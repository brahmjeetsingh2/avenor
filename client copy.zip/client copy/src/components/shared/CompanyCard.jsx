import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, IndianRupee, ArrowRight, Building2, Bookmark, BookmarkCheck } from 'lucide-react';
import Badge from '../ui/Badge';
import Countdown from './Countdown';
import StagePipeline, { getStage } from './StagePipeline';
import useAuth from '../../hooks/useAuth';
import authService from '../../services/authService';
import toast from 'react-hot-toast';

const CompanyLogo = ({ logo, name, size = 'md' }) => {
  const sizes = { sm: 'w-10 h-10 text-sm', md: 'w-14 h-14 text-lg', lg: 'w-20 h-20 text-2xl' };
  if (logo) {
    return <img src={logo} alt={name} className={`${sizes[size]} rounded-xl object-contain border border-[var(--color-border)] bg-[var(--color-surface)] p-1`} />;
  }
  const initials = name?.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  return (
    <div className={`${sizes[size]} rounded-xl bg-gradient-to-br from-cyan-500/18 to-magenta-500/14 border border-cyan-500/24 flex items-center justify-center font-display font-bold text-cyan-500`}>
      {initials || <Building2 size={20} />}
    </div>
  );
};

export { CompanyLogo };

const typeLabels = { product: 'Product', service: 'Service', startup: 'Startup', psu: 'PSU', mnc: 'MNC' };

const CompanyCard = ({ company, onApply, showApply = true }) => {
  const { user, updateUser } = useAuth();
  const [saving, setSaving] = useState(false);
  const stage = getStage(company.currentStage);
  const savedCompanyIds = useMemo(() => new Set((user?.savedCompanies || []).map(String)), [user?.savedCompanies]);
  const isSaved = savedCompanyIds.has(String(company._id));

  const formatCTC = (ctc) => {
    if (!ctc?.min && !ctc?.max) return 'CTC not disclosed';
    if (ctc.min === ctc.max) return `₹${ctc.max} LPA`;
    return `₹${ctc.min}–${ctc.max} LPA`;
  };

  const toggleSave = async () => {
    if (!company?._id || saving) return;

    setSaving(true);
    try {
      const res = await authService.toggleSavedCompany(company._id);
      if (Array.isArray(res.data?.savedCompanyIds)) {
        updateUser({ savedCompanies: res.data.savedCompanyIds });
      }
      toast.success(res.message || (res.data?.saved ? 'Company saved' : 'Company removed from saved list'));
    } catch {
      toast.error('Could not update saved companies');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card p-5 flex flex-col gap-4 hover:border-cyan-500/30 hover:shadow-glow-sm transition-all duration-300 group">
      {/* Header */}
      <div className="flex items-start gap-3">
        <CompanyLogo logo={company.logo} name={company.name} />
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-display font-bold text-[var(--color-text-primary)] text-base leading-tight group-hover:text-cyan-500 transition-colors truncate">
                {company.name}
              </h3>
              <p className="text-xs text-[var(--color-text-muted)] mt-0.5">
                {typeLabels[company.type]} · {company.sector}
              </p>
            </div>
            {/* Stage badge */}
            <span className={`shrink-0 inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-1 rounded-lg border ${stage.bg} ${stage.border} ${stage.color}`}>
              <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
              {stage.label}
            </span>
          </div>
        </div>
      </div>

      {/* Stage pipeline */}
      <div className="px-1">
        <StagePipeline currentStage={company.currentStage} compact />
      </div>

      {/* Roles */}
      {company.roles?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {company.roles.slice(0, 3).map((role) => (
            <span key={role} className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-[var(--color-border)] text-[var(--color-text-secondary)]">
              {role}
            </span>
          ))}
          {company.roles.length > 3 && (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-[var(--color-border)] text-[var(--color-text-muted)]">
              +{company.roles.length - 3} more
            </span>
          )}
        </div>
      )}

      {/* Meta row */}
      <div className="flex items-center justify-between text-xs text-[var(--color-text-muted)]">
        <div className="flex items-center gap-1 font-semibold text-[var(--color-text-secondary)]">
          <IndianRupee size={12} />
          {formatCTC(company.ctc)}
        </div>
        {company.location && (
          <div className="flex items-center gap-1">
            <MapPin size={11} /> {company.location}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-1 border-t border-[var(--color-border)]">
        <Countdown deadline={company.applicationDeadline} />
        <div className="flex items-center gap-2">
          {user?.role === 'student' && (
            <button
              type="button"
              onClick={toggleSave}
              disabled={saving}
              className="inline-flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-lg border border-[var(--color-border)] text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] hover:border-cyan-500/30 transition-colors disabled:opacity-60"
            >
              {isSaved ? <BookmarkCheck size={11} /> : <Bookmark size={11} />}
              {isSaved ? 'Saved' : 'Save'}
            </button>
          )}
          <Link
            to={`/companies/${company._id}`}
            className="text-xs font-semibold text-[var(--color-text-muted)] hover:text-cyan-500 transition-colors flex items-center gap-1"
          >
            Details <ArrowRight size={11} />
          </Link>
          {showApply && company.currentStage !== 'closed' && (
            <button
              onClick={() => onApply?.(company)}
              className="text-xs font-bold px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-white transition-colors shadow-glow-sm"
            >
              Apply
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompanyCard;
