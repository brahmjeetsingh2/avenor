import React from 'react';
import { Calendar, Clock, Link as LinkIcon, MapPin, FileText, User } from 'lucide-react';
import Modal from '../../components/ui/Modal';
import { StatusBadge, STATUS_CONFIG } from '../../utils/applicationStatus';
import { CompanyLogo } from '../../components/shared/CompanyCard';

const TimelineStep = ({ entry, isLast }) => {
  const cfg = STATUS_CONFIG[entry.status] || {};
  return (
    <div className="flex gap-3">
      <div className="flex flex-col items-center">
        <div className={`w-7 h-7 rounded-full border-2 flex items-center justify-center shrink-0 ${cfg.bg} ${cfg.border}`}>
          <span className={`w-2 h-2 rounded-full ${cfg.dot}`} />
        </div>
        {!isLast && <div className="w-0.5 flex-1 bg-[var(--color-border)] mt-1 min-h-[20px]" />}
      </div>
      <div className="pb-4 flex-1">
        <div className="flex items-center justify-between">
          <StatusBadge status={entry.status} />
          <span className="text-xs text-[var(--color-text-muted)]">
            {new Date(entry.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        {entry.note && <p className="text-sm text-[var(--color-text-secondary)] mt-1">{entry.note}</p>}
        {entry.updatedBy?.name && (
          <p className="text-xs text-[var(--color-text-muted)] mt-0.5 flex items-center gap-1">
            <User size={10} /> {entry.updatedBy.name}
          </p>
        )}
      </div>
    </div>
  );
};

const ApplicationDetailModal = ({ application, isOpen, onClose, onWithdraw }) => {
  if (!application) return null;
  const { company, status, statusHistory = [], interviewSlot, coordinatorNotes, createdAt } = application;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Application Detail" size="md">
      <div className="space-y-5">
        {/* Company header */}
        <div className="flex items-center gap-3 p-4 rounded-xl bg-[var(--color-bg)] border border-[var(--color-border)]">
          <CompanyLogo logo={company?.logo} name={company?.name} size="sm" />
          <div>
            <p className="font-bold text-[var(--color-text-primary)]">{company?.name}</p>
            <p className="text-xs text-[var(--color-text-muted)]">{company?.sector} · {company?.type}</p>
          </div>
          <div className="ml-auto">
            <StatusBadge status={status} size="md" />
          </div>
        </div>

        {/* Interview slot */}
        {interviewSlot?.date && (
          <div className="p-4 rounded-xl border border-primary-500/20 bg-primary-500/5 space-y-2">
            <p className="text-xs font-bold text-primary-400 uppercase tracking-wider">Interview Slot</p>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex items-center gap-2 text-[var(--color-text-secondary)]">
                <Calendar size={14} className="text-primary-400" />
                {new Date(interviewSlot.date).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
              </div>
              {interviewSlot.time && (
                <div className="flex items-center gap-2 text-[var(--color-text-secondary)]">
                  <Clock size={14} className="text-primary-400" /> {interviewSlot.time}
                </div>
              )}
              {interviewSlot.link && (
                <a href={interviewSlot.link} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 text-primary-400 hover:text-primary-300 col-span-2 font-medium">
                  <LinkIcon size={14} /> Join Link
                </a>
              )}
              {interviewSlot.venue && (
                <div className="flex items-center gap-2 text-[var(--color-text-secondary)] col-span-2">
                  <MapPin size={14} className="text-primary-400" /> {interviewSlot.venue}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Coordinator notes */}
        {coordinatorNotes && (
          <div className="p-4 rounded-xl bg-[var(--color-bg)] border border-[var(--color-border)]">
            <p className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-wider mb-1">Notes from Coordinator</p>
            <p className="text-sm text-[var(--color-text-secondary)]">{coordinatorNotes}</p>
          </div>
        )}

        {/* Status timeline */}
        <div>
          <p className="text-xs font-bold text-[var(--color-text-muted)] uppercase tracking-wider mb-3">Status History</p>
          <div>
            {[...statusHistory].reverse().map((entry, i, arr) => (
              <TimelineStep key={entry._id || i} entry={entry} isLast={i === arr.length - 1} />
            ))}
          </div>
        </div>

        {/* Applied date */}
        <p className="text-xs text-[var(--color-text-muted)] text-center border-t border-[var(--color-border)] pt-3">
          Applied on {new Date(createdAt).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </p>

        {/* Withdraw */}
        {!['offer', 'rejected'].includes(status) && onWithdraw && (
          <button
            onClick={() => { onWithdraw(application._id); onClose(); }}
            className="w-full text-sm text-danger-500 hover:text-danger-600 font-semibold py-2 rounded-xl hover:bg-danger-500/10 transition-colors border border-transparent hover:border-danger-500/20"
          >
            Withdraw Application
          </button>
        )}
      </div>
    </Modal>
  );
};

export default ApplicationDetailModal;
