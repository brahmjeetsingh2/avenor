import api from './api';

const companyService = {
  getAll: (params) => api.get('/companies', { params }).then((r) => r.data),
  getById: (id) => api.get(`/companies/${id}`).then((r) => r.data),
  create: (data) => api.post('/companies', data).then((r) => r.data),
  update: (id, data) => api.put(`/companies/${id}`, data).then((r) => r.data),
  updateStage: (id, data) => api.patch(`/companies/${id}/stage`, data).then((r) => r.data),
  bulkActions: (data) => api.post('/companies/bulk-actions', data).then((r) => r.data),
  workflowOverview: () => api.get('/companies/workflow/overview').then((r) => r.data),
  remove: (id) => api.delete(`/companies/${id}`).then((r) => r.data),
  getStats: () => api.get('/companies/stats').then((r) => r.data),
};

export default companyService;
