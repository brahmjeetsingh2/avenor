import api from './api';

const dashboardService = {
  getStats:    (params) => api.get('/dashboard/stats',    { params }).then(r => r.data),
  getFunnel:   ()       => api.get('/dashboard/funnel').then(r => r.data),
  getBranches: ()       => api.get('/dashboard/branches').then(r => r.data),
  getTimeline: (params) => api.get('/dashboard/timeline', { params }).then(r => r.data),
  getActivity: ()       => api.get('/dashboard/activity').then(r => r.data),
  getOperations: ()     => api.get('/dashboard/operations').then(r => r.data),
  getAlumniImpact: ()   => api.get('/dashboard/alumni-impact').then(r => r.data),
  exportCSV:   ()       => api.get('/dashboard/export', { responseType: 'blob' }).then(r => {
    const url  = URL.createObjectURL(new Blob([r.data], { type: 'text/csv' }));
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `placements-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }),
};

export default dashboardService;
