import api from './api';

const experienceService = {
  getFeed:        (params)  => api.get('/experiences', { params }).then(r => r.data),
  getById:        (id)      => api.get(`/experiences/${id}`).then(r => r.data),
  getByCompany:   (id, p)   => api.get(`/experiences/company/${id}`, { params: p }).then(r => r.data),
  search:         (q, p)    => api.get('/experiences/search', { params: { q, ...p } }).then(r => r.data),
  create:         (data)    => api.post('/experiences', data).then(r => r.data),
  upvote:         (id)      => api.patch(`/experiences/${id}/upvote`).then(r => r.data),
  delete:         (id)      => api.delete(`/experiences/${id}`).then(r => r.data),
  getStats:       (params)  => api.get('/experiences/stats', { params }).then(r => r.data),
};

export default experienceService;
