import api from './api';

const notificationService = {
  getAll:        (params) => api.get('/notifications', { params }).then(r => r.data),
  getUnread:     ()       => api.get('/notifications/unread-count').then(r => r.data),
  markRead:      (id)     => api.patch(`/notifications/${id}/read`).then(r => r.data),
  markAllRead:   ()       => api.patch('/notifications/read-all').then(r => r.data),
  delete:        (id)     => api.delete(`/notifications/${id}`).then(r => r.data),
  announce:      (data)   => api.post('/notifications/announce', data).then(r => r.data),
  previewAudience: (data) => api.post('/notifications/announce/preview-audience', data).then(r => r.data),
  getTemplates: () => api.get('/notifications/announce/templates').then(r => r.data),
  getHistory: (params) => api.get('/notifications/announce/history', { params }).then(r => r.data),
  cloneAnnouncement: (id) => api.post(`/notifications/announce/${id}/clone`).then(r => r.data),
};

export default notificationService;
