import api from './api';

const applicationService = {
  // Returns the full axios response so callers can do res.data.applications etc.
  apply:           (companyId)            => api.post('/applications', { companyId }),
  getMyApps:       (params)               => api.get('/applications/my', { params }),
  getMyStats:      ()                     => api.get('/applications/my/stats'),
  getById:         (id)                   => api.get(`/applications/${id}`),
  withdraw:        (id)                   => api.delete(`/applications/${id}`),
  getByCompany:    (companyId, params)    => api.get(`/applications/company/${companyId}`, { params }),
  getCompanyStats: (companyId)            => api.get(`/applications/company/${companyId}/stats`),
  updateStatus:    (id, data)             => api.patch(`/applications/${id}/status`, data),
  updateNotes:     (id, data)             => api.patch(`/applications/${id}/notes`, data),
  bulkStatus:      (data)                 => api.post('/applications/bulk-status', data),
  bulkSlot:        (data)                 => api.post('/applications/bulk-slot', data),
};

export default applicationService;