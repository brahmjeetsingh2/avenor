import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, ArrowRight, Zap } from 'lucide-react';
import toast from 'react-hot-toast';
import useAuth from '../../hooks/useAuth';
import BrandLogo from '../../components/shared/BrandLogo';

const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { loginUser, getDashboardPath } = useAuth();

  const [form, setForm] = useState({ email: '', password: '', rememberMe: false });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const from = location.state?.from?.pathname;

  const validate = () => {
    const errs = {};
    if (!form.email) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) errs.email = 'Enter a valid email';
    if (!form.password) errs.password = 'Password is required';
    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setLoading(true);
    setErrors({});
    try {
      const user = await loginUser({ email: form.email, password: form.password });
      toast.success(`Welcome back, ${user.name.split(' ')[0]}! 👋`);
      const destination = from || getDashboardPath(user.role);
      navigate(destination, { replace: true });
    } catch (err) {
      const msg = err.response?.data?.message || 'Login failed. Please try again.';
      toast.error(msg);
      setErrors({ general: msg });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((p) => ({ ...p, [name]: type === 'checkbox' ? checked : value }));
    if (errors[name]) setErrors((p) => ({ ...p, [name]: '' }));
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex">
      {/* ── Left panel (decorative) ── */}
      <div className="hidden lg:flex lg:w-1/2 hero-shell hero-shell--auth relative overflow-hidden bg-[linear-gradient(135deg,var(--bg),var(--surface),var(--surface-2))] items-center justify-center p-12 border-r border-[var(--color-border)] rounded-none border-0 border-r">
        {/* Orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full blur-[80px] animate-pulse-slow bg-[var(--role-cyan-tint)]" />
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 rounded-full blur-[60px] animate-pulse-slow bg-[var(--role-coral-tint)]" style={{ animationDelay: '1s' }} />

        <div className="relative z-10 max-w-sm text-center">
          {/* Logo */}
          <div className="flex items-center justify-center mb-12">
            <BrandLogo size="md" />
          </div>

          <h2 className="font-display text-4xl font-bold text-[var(--color-text-primary)] mb-4 leading-tight">
            Your placement<br />command center
          </h2>
          <p className="text-[var(--color-text-secondary)] mb-10 leading-relaxed">
            Track companies, prep for interviews, compare offers — all in one place.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { val: '500+', label: 'Companies' },
              { val: '10K+', label: 'Experiences' },
              { val: '100%', label: 'Free' },
            ].map(({ val, label }, idx) => (
              <div
                key={label}
                className={`p-4 rounded-2xl bg-[var(--surface)] border shadow-[var(--shadow-soft)] ${
                  idx === 0 ? 'border-cyan-500/20' : idx === 1 ? 'border-gold-500/20' : 'border-coral-500/20'
                }`}
              >
                <div className={`font-display text-2xl font-bold ${idx === 0 ? 'text-cyan-500' : idx === 1 ? 'text-gold-500' : 'text-coral-500'}`}>{val}</div>
                <div className="text-xs text-[var(--color-text-muted)] mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right panel (form) ── */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md animate-slide-up hero-shell hero-shell--auth p-5 md:p-6">
          {/* Header */}
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[linear-gradient(90deg,var(--role-cyan-tint),var(--role-gold-tint),var(--role-magenta-tint))] border border-[rgba(249,200,14,0.25)] text-xs font-semibold text-[var(--text-primary)] mb-4">
              <Zap size={11} />
              Welcome back
            </div>
            <h1 className="font-display text-3xl font-bold text-[var(--color-text-primary)] mb-2">
              Sign in to HireTrack
            </h1>
            <p className="text-[var(--color-text-secondary)] text-sm">
              Don't have an account?{' '}
              <Link to="/register" className="text-[var(--role-cyan)] hover:text-[var(--role-cyan-deep)] font-semibold transition-colors">
                Create one free
              </Link>
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* General error */}
            {errors.general && (
              <div className="p-3 rounded-xl bg-[var(--role-coral-tint)] border border-[rgba(248,102,36,0.22)] text-sm text-[var(--role-coral)]">
                {errors.general}
              </div>
            )}

            {/* Email */}
            <div className="space-y-1.5">
              <label className="text-sm font-semibold text-[var(--color-text-secondary)]">
                Email address
              </label>
              <div className="relative">
                <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" />
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  placeholder="you@college.edu"
                  autoComplete="email"
                  className={`w-full pl-10 pr-4 py-3 rounded-xl border bg-[var(--input-bg)] text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] text-sm outline-none transition-all
                    ${errors.email
                      ? 'border-[var(--role-coral)] focus:shadow-[var(--input-error-ring)]'
                      : 'border-[var(--color-border)] focus:border-[var(--role-cyan)] focus:shadow-[var(--input-focus-ring)]'
                    }`}
                />
              </div>
              {errors.email && <p className="text-xs text-[var(--role-coral)]">{errors.email}</p>}
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-sm font-semibold text-[var(--color-text-secondary)]">
                  Password
                </label>
                <Link to="/forgot-password" className="text-xs text-[var(--role-cyan)] hover:text-[var(--role-cyan-deep)] transition-colors font-medium">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={form.password}
                  onChange={handleChange}
                  placeholder="Your password"
                  autoComplete="current-password"
                  className={`w-full pl-10 pr-12 py-3 rounded-xl border bg-[var(--input-bg)] text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] text-sm outline-none transition-all
                    ${errors.password
                      ? 'border-[var(--role-coral)] focus:shadow-[var(--input-error-ring)]'
                      : 'border-[var(--color-border)] focus:border-[var(--role-cyan)] focus:shadow-[var(--input-focus-ring)]'
                    }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[var(--color-text-muted)] hover:text-[var(--color-text-secondary)] transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-[var(--role-coral)]">{errors.password}</p>}
            </div>

            {/* Remember me */}
            <label className="flex items-center gap-3 cursor-pointer group">
              <div className="relative">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={form.rememberMe}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
                  form.rememberMe
                    ? 'bg-[var(--role-cyan)] border-[var(--role-cyan)]'
                    : 'border-[var(--color-border)] group-hover:border-[var(--role-cyan)]'
                }`}>
                  {form.rememberMe && (
                    <svg className="w-3 h-3 text-white" viewBox="0 0 12 12" fill="none">
                      <path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  )}
                </div>
              </div>
              <span className="text-sm text-[var(--color-text-secondary)]">Remember me for 7 days</span>
            </label>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-[var(--role-cyan)] hover:bg-[var(--role-cyan-deep)] disabled:opacity-60 disabled:cursor-not-allowed text-[var(--text-reverse)] font-bold py-3.5 rounded-xl transition-all duration-200 shadow-[var(--btn-shadow-cyan)] active:scale-[0.98] mt-2"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in...
                </>
              ) : (
                <>
                  Sign In
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>

          {/* Google OAuth */}
          <a
            href={`${import.meta.env.VITE_API_URL?.replace('/api','') || 'http://localhost:8000'}/api/auth/google`}
            className="w-full flex items-center justify-center gap-3 border border-[var(--color-border)] hover:border-[var(--role-cyan)] text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] font-semibold py-3.5 rounded-xl transition-all duration-200 text-sm bg-[var(--color-card)] mt-3"
          >
            <svg width="18" height="18" viewBox="0 0 18 18"><path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#5AA9E6"/><path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#FF6392"/><path d="M3.964 10.707A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.707V4.961H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.039l3.007-2.332z" fill="#F9C80E"/><path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.961L3.964 6.293C4.672 4.166 6.656 3.58 9 3.58z" fill="#EA3546"/></svg>
            Continue with Google
          </a>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-[var(--color-border)]" />
            <span className="text-xs text-[var(--color-text-muted)]">or</span>
            <div className="flex-1 h-px bg-[var(--color-border)]" />
          </div>

          {/* Register CTA */}
          <Link
            to="/register"
            className="w-full flex items-center justify-center gap-2 border border-[var(--color-border)] hover:border-[var(--role-cyan)] text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] font-semibold py-3.5 rounded-xl transition-all duration-200 text-sm"
          >
            Create a new account
          </Link>

          {/* Footer note */}
          <p className="text-center text-xs text-[var(--color-text-muted)] mt-6">
            By signing in, you agree to HireTrack's terms of service
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
