import React, { useEffect, useMemo, useState } from 'react';
import { Award, Copy, ExternalLink, Linkedin, Pencil, Plus, Share2, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import useAuth from '../../hooks/useAuth';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import referralService from '../../services/referralService';

const DRAFT_KEY = 'hiretrack:referral-draft';

const emptyForm = {
  role: '',
  company: '',
  location: '',
  type: 'Full-time',
  description: '',
  link: '',
  linkedin: '',
  expiresAt: '',
};

const toDateInputValue = (value) => {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const tzOffsetMs = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - tzOffsetMs).toISOString().slice(0, 10);
};

const PostReferralModal = ({ isOpen, onClose, onSaved, editing }) => {
  const { user } = useAuth();
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (editing) {
      setForm({
        role: editing.role || '',
        company: editing.company || '',
        location: editing.location || '',
        type: editing.type || 'Full-time',
        description: editing.description || '',
        link: editing.link || '',
        linkedin: editing.linkedin || '',
        expiresAt: toDateInputValue(editing.expiresAt),
      });
      return;
    }

    const key = `${DRAFT_KEY}:${user?._id || 'guest'}`;
    const raw = localStorage.getItem(key);
    if (!raw) {
      setForm(emptyForm);
      return;
    }

    try {
      const parsed = JSON.parse(raw);
      setForm({ ...emptyForm, ...parsed });
    } catch {
      setForm(emptyForm);
    }
  }, [editing, user?._id, isOpen]);

  useEffect(() => {
    if (!isOpen || editing) return;
    const key = `${DRAFT_KEY}:${user?._id || 'guest'}`;
    localStorage.setItem(key, JSON.stringify(form));
  }, [form, isOpen, editing, user?._id]);

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const submit = async () => {
    if (!form.role.trim() || !form.company.trim()) {
      toast.error('Role and company are required');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        ...form,
        expiresAt: form.expiresAt || null,
      };

      if (editing?._id) {
        await referralService.update(editing._id, payload);
        toast.success('Referral updated');
      } else {
        await referralService.create(payload);
        toast.success('Referral posted and visible to students');
        localStorage.removeItem(`${DRAFT_KEY}:${user?._id || 'guest'}`);
      }

      onSaved();
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save referral');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={editing ? 'Edit Referral' : 'Post Referral'}
      size="md"
      footer={<><Button variant="ghost" onClick={onClose}>Cancel</Button><Button onClick={submit} loading={loading}>{editing ? 'Save Changes' : 'Post Referral'}</Button></>}
    >
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <label className="text-xs font-semibold">Role *</label>
            <input className="input" value={form.role} onChange={(e) => set('role', e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-semibold">Company *</label>
            <input className="input" value={form.company} onChange={(e) => set('company', e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-semibold">Location</label>
            <input className="input" value={form.location} onChange={(e) => set('location', e.target.value)} />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold">Type</label>
          <select className="input" value={form.type} onChange={(e) => set('type', e.target.value)}>
            <option>Full-time</option>
            <option>Internship</option>
            <option>Contract</option>
          </select>
        </div>

        <div>
          <label className="text-xs font-semibold">Description</label>
          <textarea className="input min-h-24" value={form.description} onChange={(e) => set('description', e.target.value)} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold">Job link</label>
            <input className="input" value={form.link} onChange={(e) => set('link', e.target.value)} />
          </div>
          <div>
            <label className="text-xs font-semibold">LinkedIn</label>
            <input className="input" value={form.linkedin} onChange={(e) => set('linkedin', e.target.value)} />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold">Expiry date</label>
          <input type="date" className="input" value={form.expiresAt} onChange={(e) => set('expiresAt', e.target.value)} />
        </div>
      </div>
    </Modal>
  );
};

const AlumniReferralsPage = () => {
  const [tab, setTab] = useState('mine');
  const [mine, setMine] = useState([]);
  const [browse, setBrowse] = useState([]);
  const [filters, setFilters] = useState({ type: '', company: '', status: 'active', sort: 'newest' });
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [mineRes, browseRes] = await Promise.all([
        referralService.listMine({ sort: filters.sort, status: filters.status }),
        referralService.list(filters),
      ]);
      setMine(mineRes.data.referrals || []);
      setBrowse(browseRes.data || []);
    } catch {
      toast.error('Failed to load referrals');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filters.status, filters.sort, filters.company, filters.type]);

  const rows = tab === 'mine' ? mine : browse;

  const summary = useMemo(() => ({
    total: mine.length,
    active: mine.filter((r) => r.lifecycleStatus === 'active' || r.lifecycleStatus === 'closing_soon').length,
    helped: mine.reduce((sum, r) => sum + (r.clicks || 0) + (r.saveCount || 0) + (r.applyIntentCount || 0), 0),
  }), [mine]);

  const remove = async (id) => {
    try {
      await referralService.remove(id);
      toast.success('Referral removed');
      fetchData();
    } catch {
      toast.error('Failed to remove referral');
    }
  };

  const updateStatus = async (id, status) => {
    try {
      await referralService.update(id, { status });
      toast.success('Referral status updated');
      fetchData();
    } catch {
      toast.error('Could not update status');
    }
  };

  const copyText = async (r) => {
    const text = `${r.role} at ${r.company}${r.location ? ` (${r.location})` : ''}\n${r.description || ''}\n${r.link || ''}`;
    await navigator.clipboard.writeText(text);
    toast.success('Referral text copied');
  };

  const shareWhatsApp = (r) => {
    const text = encodeURIComponent(`${r.role} at ${r.company}\n${r.description || ''}\n${r.link || ''}`);
    window.open(`https://wa.me/?text=${text}`, '_blank', 'noopener,noreferrer');
  };

  const shareLinkedIn = (r) => {
    const url = encodeURIComponent(r.link || window.location.href);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6 page-enter space-y-5">
      <div className="card p-5 bg-gradient-to-r from-coral-500/14 via-gold-500/10 to-cyan-500/10 border-coral-500/30 shadow-[0_24px_60px_-42px_rgba(233,95,88,.95)]">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="font-display text-2xl font-bold">Referrals</h1>
            <p className="text-sm text-[var(--color-text-muted)] mt-1">Manage alumni referrals with lifecycle and impact tracking.</p>
          </div>
          <Button leftIcon={<Plus size={14} />} onClick={() => { setEditing(null); setModalOpen(true); }}>Post Referral</Button>
        </div>

        <div className="grid sm:grid-cols-3 gap-3 mt-4">
          <div className="rounded-xl border border-[var(--color-border)] p-3 bg-[var(--color-surface)]"><p className="text-xs text-[var(--color-text-muted)]">Referrals posted</p><p className="font-display text-2xl font-bold">{summary.total}</p></div>
          <div className="rounded-xl border border-[var(--color-border)] p-3 bg-[var(--color-surface)]"><p className="text-xs text-[var(--color-text-muted)]">Active now</p><p className="font-display text-2xl font-bold">{summary.active}</p></div>
          <div className="rounded-xl border border-[var(--color-border)] p-3 bg-[var(--color-surface)]"><p className="text-xs text-[var(--color-text-muted)]">Students helped</p><p className="font-display text-2xl font-bold">{summary.helped}</p></div>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={() => setTab('mine')} className={`px-3 py-2 rounded-xl text-sm font-semibold ${tab === 'mine' ? 'bg-coral-500 text-white shadow-[0_14px_34px_-24px_rgba(233,95,88,.95)]' : 'bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'}`}>My Referrals</button>
        <button onClick={() => setTab('browse')} className={`px-3 py-2 rounded-xl text-sm font-semibold ${tab === 'browse' ? 'bg-coral-500 text-white shadow-[0_14px_34px_-24px_rgba(233,95,88,.95)]' : 'bg-[var(--color-surface)] border border-[var(--color-border)] text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)]'}`}>Browse Referrals</button>

        <select className="input max-w-40" value={filters.type} onChange={(e) => setFilters((p) => ({ ...p, type: e.target.value }))}>
          <option value="">All types</option>
          <option value="Full-time">Full-time</option>
          <option value="Internship">Internship</option>
          <option value="Contract">Contract</option>
        </select>
        <input
          className="input max-w-56"
          placeholder="Filter by company"
          value={filters.company}
          onChange={(e) => setFilters((p) => ({ ...p, company: e.target.value }))}
        />
        <select className="input max-w-40" value={filters.status} onChange={(e) => setFilters((p) => ({ ...p, status: e.target.value }))}>
          <option value="active">Active</option>
          <option value="closing_soon">Closing soon</option>
          <option value="expired">Expired</option>
          <option value="filled">Filled</option>
        </select>
        <select className="input max-w-40" value={filters.sort} onChange={(e) => setFilters((p) => ({ ...p, sort: e.target.value }))}>
          <option value="newest">Newest</option>
          <option value="company">Company</option>
          <option value="impact">Impact</option>
        </select>
      </div>

      {loading ? <div className="card p-8 text-sm">Loading referrals...</div> : rows.length === 0 ? (
        <div className="card p-10 text-center">
          <Award size={24} className="mx-auto text-[var(--color-text-muted)] mb-3" />
          <p className="font-semibold">Post your first referral</p>
          <p className="text-sm text-[var(--color-text-muted)] mt-1">It becomes instantly visible to students from your college.</p>
          <Button className="mt-4" onClick={() => { setEditing(null); setModalOpen(true); }}>Create Referral</Button>
        </div>
      ) : (
        <div className="space-y-3 stagger-children">
          {rows.map((r) => (
            <div key={r._id} className="card p-4 space-y-3 hover-lift">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-bold">{r.role}</h3>
                  <p className="text-sm text-[var(--color-text-muted)]">{r.company}{r.location ? ` · ${r.location}` : ''}</p>
                </div>
                <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-coral-500/12 border border-coral-500/30 text-coral-500">{r.lifecycleStatus.replace('_', ' ')}</span>
              </div>

              {r.description ? <p className="text-sm text-[var(--color-text-secondary)]">{r.description}</p> : null}

              <div className="flex flex-wrap gap-2 text-xs">
                {r.link ? <a className="inline-flex items-center gap-1.5 text-coral-500 hover:text-coral-400 transition-colors font-semibold" href={r.link} target="_blank" rel="noopener noreferrer"><ExternalLink size={12} /> Job Link</a> : null}
                {r.linkedin ? <a className="inline-flex items-center gap-1.5 text-magenta-500 hover:text-magenta-400 transition-colors font-semibold" href={r.linkedin} target="_blank" rel="noopener noreferrer"><Linkedin size={12} /> LinkedIn</a> : null}
                <button onClick={() => copyText(r)} className="inline-flex items-center gap-1.5 text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] transition-colors font-semibold"><Copy size={12} /> Copy Text</button>
                <button onClick={() => shareWhatsApp(r)} className="inline-flex items-center gap-1.5 text-[var(--color-text-muted)] hover:text-gold-500 transition-colors font-semibold"><Share2 size={12} /> WhatsApp</button>
                <button onClick={() => shareLinkedIn(r)} className="inline-flex items-center gap-1.5 text-[var(--color-text-muted)] hover:text-cyan-500 transition-colors font-semibold"><Share2 size={12} /> LinkedIn</button>
              </div>

              {tab === 'mine' && (
                <div className="flex items-center justify-between pt-2 border-t border-[var(--color-border)]">
                  <p className="text-xs text-[var(--color-text-muted)]">{r.clicks || 0} clicks · {r.saveCount || 0} saves · {r.applyIntentCount || 0} apply intents</p>
                  <div className="flex items-center gap-2">
                    <select className="input !py-1 !px-2 text-xs" value={r.status} onChange={(e) => updateStatus(r._id, e.target.value)}>
                      <option value="active">Active</option>
                      <option value="closed">Expired</option>
                      <option value="filled">Filled</option>
                    </select>
                    <button className="p-2 rounded-lg hover:bg-coral-500/12 hover:text-coral-500 transition-colors" onClick={() => { setEditing(r); setModalOpen(true); }}><Pencil size={13} /></button>
                    <button className="p-2 rounded-lg hover:bg-danger-500/10 text-danger-500" onClick={() => remove(r._id)}><Trash2 size={13} /></button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <PostReferralModal
        isOpen={modalOpen}
        editing={editing}
        onClose={() => setModalOpen(false)}
        onSaved={fetchData}
      />
    </div>
  );
};

export default AlumniReferralsPage;
