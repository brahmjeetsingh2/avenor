import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BookOpen, PenLine, Sparkles } from 'lucide-react';
import ExperienceFeedPage from '../shared/ExperienceFeedPage';

const AlumniExperienceHubPage = () => {
  const location = useLocation();
  const summary = location.state?.experienceSummary;

  return (
    <div className="space-y-4">
      <div className="mx-auto max-w-5xl px-4 md:px-6 pt-4">
        <div className="card p-5 md:p-6 bg-gradient-to-r from-coral-500/14 via-gold-500/10 to-cyan-500/10 border-coral-500/28 shadow-[0_24px_56px_-42px_rgba(233,95,88,.92)]">
          <div className="flex items-start justify-between gap-4 flex-wrap">
            <div>
              <h1 className="font-display text-2xl font-bold text-[var(--color-text-primary)]">Experience Hub</h1>
              <p className="text-sm text-[var(--color-text-muted)] mt-1">
                Browse community experiences and quickly share your own in a dedicated alumni flow.
              </p>
            </div>
            <Link
              to="/alumni/experiences/new"
              className="inline-flex items-center gap-2 bg-coral-500 hover:bg-coral-400 text-white font-bold px-4 py-2.5 rounded-xl text-sm shadow-[0_14px_32px_-24px_rgba(233,95,88,.95)] transition-colors"
            >
              <PenLine size={14} /> Share Experience
            </Link>
          </div>

          {summary && (
            <div className="mt-4 rounded-xl border border-coral-500/30 bg-coral-500/12 p-3 text-sm text-coral-600 dark:text-coral-400 flex items-center gap-2">
              <Sparkles size={14} />
              Shared successfully: {summary.company} - {summary.role}. Thanks for helping juniors prepare.
            </div>
          )}

          <div className="mt-4 grid sm:grid-cols-2 gap-3">
            <div className="rounded-xl border border-[var(--color-border)] p-3 bg-[var(--color-surface)]">
              <p className="text-xs font-semibold text-[var(--color-text-muted)]">Browse Experiences</p>
              <p className="text-sm text-[var(--color-text-secondary)] mt-1">Find interview patterns, round breakdowns, and practical tips.</p>
            </div>
            <div className="rounded-xl border border-[var(--color-border)] p-3 bg-[var(--color-surface)]">
              <p className="text-xs font-semibold text-[var(--color-text-muted)]">Share Experience</p>
              <p className="text-sm text-[var(--color-text-secondary)] mt-1">Use the guided form to post your interview journey in minutes.</p>
            </div>
          </div>
        </div>
      </div>

      <ExperienceFeedPage />
    </div>
  );
};

export default AlumniExperienceHubPage;
