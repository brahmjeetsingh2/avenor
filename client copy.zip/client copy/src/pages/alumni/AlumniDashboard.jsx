import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Award, BookOpen, CalendarClock, DollarSign, Plus, Sparkles, Users } from 'lucide-react';
import toast from 'react-hot-toast';
import useAuth from '../../hooks/useAuth';
import Avatar from '../../components/ui/Avatar';
import dashboardService from '../../services/dashboardService';

const StatCard = ({ icon: Icon, label, value, to, tone, hoverBorder = 'hover:border-[var(--role-cyan)]' }) => (
  <Link to={to} className={`card p-5 flex items-center gap-4 ${hoverBorder} hover:shadow-glow-sm transition-all group`}>
    <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${tone}`}>
      <Icon size={18} />
    </div>
    <div className="flex-1">
      <p className="font-display text-2xl font-bold text-[var(--color-text-primary)] leading-none">{value}</p>
      <p className="text-xs text-[var(--color-text-muted)] mt-1">{label}</p>
    </div>
    <ArrowRight size={14} className="text-[var(--color-text-muted)] group-hover:text-[var(--role-cyan)]" />
  </Link>
);

const AlumniDashboard = () => {
  const { user } = useAuth();
  const [impact, setImpact] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await dashboardService.getAlumniImpact();
        setImpact(res.data);
      } catch {
        toast.error('Failed to load alumni dashboard');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  return (
    <div className="p-4 md:p-6 page-enter space-y-6">
      <div className="card hero-shell hero-shell--alumni p-6 border-[rgba(248,102,36,0.24)]" style={{ background: 'linear-gradient(90deg, var(--role-coral-tint), var(--role-cyan-tint), var(--role-magenta-tint))' }}>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <Avatar name={user?.name} src={user?.profilePic} size="lg" />
            <div>
              <h1 className="font-display text-2xl font-bold text-[var(--color-text-primary)]">Alumni Impact Dashboard</h1>
              <p className="text-sm text-[var(--color-text-muted)] mt-1">Track your contributions and help more students with clear next actions.</p>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap">
            <Link to="/alumni/experiences/new" className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--role-cyan)] text-[var(--text-reverse)] text-sm font-bold shadow-[var(--btn-shadow-cyan)]">
              <BookOpen size={14} /> Share Experience
            </Link>
            <Link to="/alumni/referrals" className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-[var(--role-coral)] text-[var(--text-reverse)] text-sm font-bold shadow-[var(--btn-shadow-coral)]">
              <Award size={14} /> Post Referral
            </Link>
            <Link to="/alumni/salary" className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-[linear-gradient(90deg,var(--gradient-pro-start),var(--gradient-pro-end))] text-[var(--text-reverse)] text-sm font-bold shadow-[var(--btn-shadow-gold)]">
              <DollarSign size={14} /> Submit Salary
            </Link>
          </div>
        </div>
      </div>

      {loading || !impact ? (
        <div className="card p-8 text-sm">Loading your impact...</div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={BookOpen} label="Experiences Shared" value={impact.experiencesShared} to="/alumni/experiences" tone="bg-[var(--role-cyan-tint)] text-[var(--role-cyan)]" hoverBorder="hover:border-[var(--role-cyan)]" />
            <StatCard icon={Award} label="Referrals Posted" value={impact.referralsPosted} to="/alumni/referrals" tone="bg-[var(--role-coral-tint)] text-[var(--role-coral)]" hoverBorder="hover:border-[var(--role-coral)]" />
            <StatCard icon={Users} label="Students Helped" value={impact.studentsHelped} to="/alumni/referrals" tone="bg-[var(--role-gold-tint)] text-[var(--role-gold)]" hoverBorder="hover:border-[var(--role-gold)]" />
            <StatCard icon={DollarSign} label="Salary Contributions" value={impact.salaryContributions} to="/alumni/salary" tone="bg-[var(--role-magenta-tint)] text-[var(--role-magenta)]" hoverBorder="hover:border-[var(--role-magenta)]" />
          </div>

          <div className="grid lg:grid-cols-2 gap-5">
            <div className="card p-5 space-y-3">
              <h2 className="font-display font-bold text-base">Recent Contributions</h2>
              {impact.recentImpact?.length ? impact.recentImpact.map((item, idx) => (
                <div key={`${item.type}-${idx}`} className="rounded-xl border border-[var(--color-border)] p-3 flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold">{item.title}</p>
                    <p className="text-xs text-[var(--color-text-muted)] mt-1">{item.meta}</p>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-[var(--color-text-muted)]">{item.type}</span>
                </div>
              )) : (
                <div className="rounded-xl border border-[var(--color-border)] p-4 text-sm text-[var(--color-text-muted)]">
                  Share your first experience to start your impact timeline.
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="card p-5">
                <h2 className="font-display font-bold text-base flex items-center gap-2"><Sparkles size={15} className="text-[var(--role-cyan)]" /> Alumni Analytics</h2>
                <div className="mt-3 space-y-2 text-sm">
                  <div className="flex items-center justify-between"><span className="text-[var(--color-text-muted)]">Companies contributed to</span><span className="font-semibold">{impact.companiesContributedTo}</span></div>
                  <div className="flex items-center justify-between"><span className="text-[var(--color-text-muted)]">Referral clicks</span><span className="font-semibold">{impact.referralClicks}</span></div>
                  <div className="flex items-center justify-between"><span className="text-[var(--color-text-muted)]">Students helped this month</span><span className="font-semibold">{impact.studentsHelpedThisMonth}</span></div>
                </div>
              </div>

              <div className="card p-5">
                <h2 className="font-display font-bold text-base flex items-center gap-2"><CalendarClock size={15} className="text-[var(--role-gold)]" /> Upcoming Referral Expiries</h2>
                <div className="mt-3 space-y-2">
                  {impact.upcomingReferralExpiries?.length ? impact.upcomingReferralExpiries.map((r) => (
                    <div key={r._id} className="rounded-xl border border-[var(--color-border)] p-3">
                      <p className="text-sm font-semibold">{r.company} - {r.role}</p>
                      <p className="text-xs text-[var(--color-text-muted)] mt-1">Expires {new Date(r.expiresAt).toLocaleDateString('en-IN')}</p>
                    </div>
                  )) : <p className="text-sm text-[var(--color-text-muted)]">No referral expiries in the next 14 days.</p>}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AlumniDashboard;
