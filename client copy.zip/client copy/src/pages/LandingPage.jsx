import React from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Sparkles,
  GraduationCap,
  Building2,
  Award,
  Bell,
  BrainCircuit,
  DollarSign,
  Search,
  BarChart3,
  CheckCircle2,
} from 'lucide-react';
import BrandLogo from '../components/shared/BrandLogo';

const features = [
  { icon: Bell, title: 'Instant Placement Alerts', desc: 'Announcements, deadlines, interview slots, and offer updates in one feed.' },
  { icon: BrainCircuit, title: 'AI Interview Prep', desc: 'Role-specific prep generated from historical experiences and real placement outcomes.' },
  { icon: DollarSign, title: 'Real Salary Insights', desc: 'Anonymous salary data helps students benchmark and negotiate with confidence.' },
  { icon: Search, title: 'Experience Search', desc: 'Search by company, role, branch, and topic with fast relevance ranking.' },
  { icon: BarChart3, title: 'Coordinator Analytics', desc: 'Track funnel health, branch outcomes, and placement velocity in one dashboard.' },
  { icon: Award, title: 'Alumni Referral Network', desc: 'Structured referrals and mentorship requests with lifecycle visibility.' },
];

const featureStyles = [
  {
    iconWrap: 'border-cyan-500/28 bg-cyan-500/12 text-cyan-600',
    cardBorder: 'border-cyan-500/18 hover:border-cyan-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(90,169,230,.16), transparent 70%)',
  },
  {
    iconWrap: 'border-gold-500/28 bg-gold-500/12 text-gold-700',
    cardBorder: 'border-gold-500/18 hover:border-gold-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(249,200,14,.16), transparent 70%)',
  },
  {
    iconWrap: 'border-coral-500/28 bg-coral-500/12 text-coral-600',
    cardBorder: 'border-coral-500/18 hover:border-coral-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(248,102,36,.14), transparent 70%)',
  },
  {
    iconWrap: 'border-magenta-500/28 bg-magenta-500/12 text-magenta-600',
    cardBorder: 'border-magenta-500/18 hover:border-magenta-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(255,99,146,.14), transparent 70%)',
  },
  {
    iconWrap: 'border-cyan-500/28 bg-cyan-500/12 text-cyan-600',
    cardBorder: 'border-cyan-500/18 hover:border-cyan-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(127,200,248,.18), transparent 70%)',
  },
  {
    iconWrap: 'border-coral-500/28 bg-coral-500/12 text-coral-600',
    cardBorder: 'border-coral-500/18 hover:border-coral-500/38',
    glow: 'radial-gradient(26rem 14rem at 8% 4%, rgba(248,102,36,.16), transparent 70%)',
  },
];

const roles = [
  {
    icon: GraduationCap,
    name: 'Students',
    desc: 'Track every company cycle, prepare smarter, and compare offers before deciding.',
    accent: 'text-cyan-500',
    bg: 'bg-cyan-500/12 border-cyan-500/28',
  },
  {
    icon: Building2,
    name: 'Coordinators',
    desc: 'Run placements at scale with clean communication workflows and analytics.',
    accent: 'text-gold-500',
    bg: 'bg-gold-500/12 border-gold-500/28',
  },
  {
    icon: Award,
    name: 'Alumni',
    desc: 'Share experiences, referrals, and guidance that improve real campus outcomes.',
    accent: 'text-coral-500',
    bg: 'bg-coral-500/12 border-coral-500/28',
  },
];

const LandingPage = () => {
  return (
    <div className="min-h-screen overflow-x-hidden bg-[var(--bg)]">
      <section className="relative px-4 sm:px-6 pt-16 pb-12 md:pt-28 md:pb-20">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            backgroundImage:
              'radial-gradient(52rem 28rem at 18% 4%, rgba(249,200,14,.17), transparent 72%), radial-gradient(44rem 24rem at 88% 18%, rgba(90,169,230,.15), transparent 76%), radial-gradient(36rem 22rem at 56% 86%, rgba(255,99,146,.13), transparent 74%)',
          }}
        />

        <div className="relative max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-gold-500/30 bg-gold-500/12 text-gold-600 text-[10px] sm:text-xs font-semibold tracking-[0.06em] uppercase page-enter">
            <Sparkles size={13} /> Premium Placement OS
          </div>

          <div className="mt-6 flex flex-col gap-10 lg:flex-row lg:items-start lg:justify-between">
            <div className="max-w-3xl page-enter" style={{ animationDelay: '0.06s' }}>
              <BrandLogo size="lg" className="mb-8" />
              <h1 className="font-display text-[clamp(2rem,9vw,5rem)] leading-[0.95] tracking-[-0.045em] text-[var(--text-primary)]">
                Placement season,
                <span className="block text-transparent bg-clip-text bg-[linear-gradient(120deg,var(--role-cyan),var(--role-gold),var(--role-magenta))]">
                  redesigned for winners.
                </span>
              </h1>
              <p className="mt-5 max-w-2xl text-[14px] sm:text-[15px] md:text-[18px] leading-relaxed text-[var(--text-secondary)]">
                HireTrack unifies announcements, company progress, applications, AI prep, mentorship, and salary signals into one premium command center for your college ecosystem.
              </p>

              <div className="mt-7 flex flex-col sm:flex-row sm:flex-wrap items-stretch sm:items-center gap-3">
                <Link to="/register" className="btn-primary h-11 px-6 rounded-xl text-sm font-bold justify-center">
                  Start Free <ArrowRight size={14} />
                </Link>
                <Link to="/login" className="btn-secondary h-11 px-6 rounded-xl text-sm font-semibold justify-center">
                  Existing User Sign In
                </Link>
              </div>
            </div>

            <div className="w-full lg:w-[360px] page-enter" style={{ animationDelay: '0.14s' }}>
              <div className="card hero-shell hero-shell--landing p-6 border-gold-500/28 bg-[linear-gradient(165deg,var(--surface),var(--surface-2))] relative overflow-hidden">
                <div
                  aria-hidden
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    backgroundImage:
                      'radial-gradient(18rem 11rem at 95% 0%, rgba(249,200,14,.2), transparent 72%), radial-gradient(14rem 10rem at 8% 98%, rgba(90,169,230,.17), transparent 74%)',
                  }}
                />
                <p className="text-xs uppercase tracking-[0.09em] text-gold-600 font-bold">This Week At A Glance</p>
                <div className="mt-5 space-y-3">
                  {[
                    '47 new company updates',
                    '132 students in interview rounds',
                    '28 alumni mentorship replies',
                    '11 fresh referral opportunities',
                  ].map((line, idx) => (
                    <div key={line} className="flex items-center gap-2.5 text-sm text-[var(--text-secondary)] relative z-[1]">
                      <CheckCircle2
                        size={14}
                        className={idx % 3 === 0 ? 'text-cyan-500' : idx % 3 === 1 ? 'text-gold-500' : 'text-magenta-500'}
                      />
                      {line}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 sm:px-6 py-8 md:py-12">
        <div className="max-w-6xl mx-auto grid gap-4 md:grid-cols-2 lg:grid-cols-3 stagger-children">
          {features.map(({ icon: Icon, title, desc }, index) => {
            const style = featureStyles[index % featureStyles.length];
            return (
            <article
              key={title}
              className={`card p-6 hover-lift ${style.cardBorder} relative overflow-hidden`}
              style={{ backgroundImage: style.glow }}
            >
              <div className={`w-11 h-11 rounded-xl border flex items-center justify-center ${style.iconWrap}`}>
                <Icon size={18} />
              </div>
              <h3 className="mt-4 font-display text-xl font-bold text-[var(--text-primary)]">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-[var(--text-secondary)]">{desc}</p>
            </article>
          )})}
        </div>
      </section>

      <section className="px-4 sm:px-6 py-10 md:py-14">
        <div className="max-w-6xl mx-auto">
          <div className="mb-7 page-enter">
            <p className="text-xs uppercase tracking-[0.1em] font-bold text-gold-600">Built For Every Role</p>
            <h2 className="mt-2 font-display text-2xl sm:text-3xl md:text-4xl tracking-[-0.035em] text-[var(--text-primary)]">
              One platform. Three powerful workflows.
            </h2>
          </div>

          <div className="grid gap-4 md:grid-cols-3 stagger-children">
            {roles.map(({ icon: Icon, name, desc, accent, bg }) => (
              <article key={name} className="card p-6 hover-lift">
                <div className={`w-12 h-12 rounded-2xl border flex items-center justify-center ${bg} ${accent}`}>
                  <Icon size={20} />
                </div>
                <h3 className="mt-4 font-display text-2xl font-bold text-[var(--text-primary)]">{name}</h3>
                <p className="mt-2 text-sm text-[var(--text-secondary)] leading-relaxed">{desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 sm:px-6 pt-4 pb-16 md:pb-24">
        <div className="max-w-6xl mx-auto card hero-shell hero-shell--landing p-8 md:p-12 border-gold-500/30 bg-[linear-gradient(145deg,rgba(249,200,14,.14),rgba(90,169,230,.1),rgba(249,249,249,.98))] relative overflow-hidden">
          <div
            aria-hidden
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage:
                'radial-gradient(24rem 12rem at 10% 0%, rgba(255,99,146,.16), transparent 70%), radial-gradient(26rem 14rem at 92% 100%, rgba(248,102,36,.16), transparent 74%)',
            }}
          />
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.1em] font-bold text-gold-700">Ready To Launch</p>
              <h3 className="mt-2 font-display text-2xl sm:text-3xl md:text-4xl leading-[1.02] tracking-[-0.04em] text-[var(--text-primary)]">
                Build your strongest placement season yet.
              </h3>
            </div>
            <div className="flex gap-3 flex-wrap">
              <Link to="/register" className="btn-primary h-11 px-6 rounded-xl text-sm font-bold">Create Account</Link>
              <Link to="/login" className="btn-secondary h-11 px-6 rounded-xl text-sm font-semibold">Go To Dashboard</Link>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto mt-8 flex flex-wrap items-center justify-between gap-3 text-sm text-[var(--text-muted)]">
          <BrandLogo size="xs" />
          <p>Designed for modern campus hiring teams and ambitious students.</p>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
