import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, Globe, MapPin, IndianRupee, Users, FileText,
  Calendar, ChevronDown, ChevronUp, Edit, Trash2, ExternalLink,
  CheckCircle, Clock, Building2, BrainCircuit, Bookmark, BookmarkCheck,
} from 'lucide-react';
import toast from 'react-hot-toast';
import companyService from '../../services/companyService';
import applicationService from '../../services/applicationService';
import useAuth from '../../hooks/useAuth';
import authService from '../../services/authService';
import StagePipeline, { STAGES, getStage } from '../../components/shared/StagePipeline';
import Countdown from '../../components/shared/Countdown';
import { CompanyDetailSkeleton } from '../../components/shared/Skeleton';
import { CompanyLogo } from '../../components/shared/CompanyCard';
import UpdateStageModal from './UpdateStageModal';

// ─── Info row ─────────────────────────────────────────────────────────────────
const InfoRow = ({ icon: Icon, label, value }) => {
  if (!value) return null;
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}
      className="last-info-row">
      <Icon size={14} style={{ color: 'var(--text-muted)', marginTop: 2, flexShrink: 0 }} />
      <div>
        <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 2 }}>{label}</p>
        <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{value}</p>
      </div>
    </div>
  );
};

// ─── Timeline entry ───────────────────────────────────────────────────────────
const TimelineEntry = ({ entry, isLast }) => {
  const stage = getStage(entry.stage);
  return (
    <div style={{ display: 'flex', gap: 14 }}>
      {/* Connector column */}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{
          width: 30, height: 30, borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: stage.bg, border: `2px solid ${stage.border || 'var(--border)'}`,
          flexShrink: 0,
        }}>
          <CheckCircle size={13} style={{ color: stage.color }} />
        </div>
        {!isLast && <div style={{ width: 1, flex: 1, background: 'var(--border)', marginTop: 4 }} />}
      </div>

      {/* Content */}
      <div style={{ paddingBottom: isLast ? 0 : 20, flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <span style={{ fontSize: 13, fontWeight: 700, textTransform: 'capitalize', color: stage.color }}>
            {entry.stage}
          </span>
          <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>
            {new Date(entry.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
          </span>
        </div>
        {entry.description && (
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{entry.description}</p>
        )}
        {entry.updatedBy?.name && (
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>by {entry.updatedBy.name}</p>
        )}
      </div>
    </div>
  );
};

// ─── Card wrapper ─────────────────────────────────────────────────────────────
const Card = ({ children, style = {} }) => (
  <div style={{
    background:   'var(--surface)',
    border:       '1px solid var(--border)',
    borderRadius: 'var(--radius-card)',
    boxShadow:    'var(--shadow-soft)',
    ...style,
  }}>
    {children}
  </div>
);

// ─── Card heading ─────────────────────────────────────────────────────────────
const CardHeading = ({ icon: Icon, iconBg, iconColor, children, action }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
    <h2 style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: 15, fontWeight: 700, color: 'var(--text-primary)' }}>
      {Icon && (
        <span style={{ width: 28, height: 28, borderRadius: 8, background: iconBg || 'var(--surface-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon size={14} style={{ color: iconColor || 'var(--text-muted)' }} />
        </span>
      )}
      {children}
    </h2>
    {action}
  </div>
);

// ─── Icon action button ───────────────────────────────────────────────────────
const IconBtn = ({ onClick, title, danger, as: Tag = 'button', to, children }) => {
  const style = {
    width: 36, height: 36, borderRadius: 10,
    border: '1px solid var(--border)', background: 'transparent',
    color: 'var(--text-muted)', display: 'flex', alignItems: 'center',
    justifyContent: 'center', cursor: 'pointer', textDecoration: 'none',
    transition: 'color 0.15s ease, border-color 0.15s ease, background 0.15s ease',
    flexShrink: 0,
  };
  const hoverIn  = (e) => {
    if (danger) {
      e.currentTarget.style.color       = 'var(--danger)';
      e.currentTarget.style.borderColor = 'rgba(255,69,58,0.3)';
      e.currentTarget.style.background  = 'rgba(255,69,58,0.08)';
    } else {
      e.currentTarget.style.color       = 'var(--text-primary)';
      e.currentTarget.style.borderColor = 'rgba(10,132,255,0.3)';
    }
  };
  const hoverOut = (e) => {
    e.currentTarget.style.color       = 'var(--text-muted)';
    e.currentTarget.style.borderColor = 'var(--border)';
    e.currentTarget.style.background  = 'transparent';
  };

  if (Tag === Link) {
    return <Link to={to} style={style} title={title} onMouseEnter={hoverIn} onMouseLeave={hoverOut}>{children}</Link>;
  }
  return <button onClick={onClick} style={style} title={title} onMouseEnter={hoverIn} onMouseLeave={hoverOut}>{children}</button>;
};

// ─── Main component ───────────────────────────────────────────────────────────
const CompanyDetailPage = () => {
  const { id }        = useParams();
  const navigate      = useNavigate();
  const { user, updateUser }      = useAuth();
  const isCoordinator = user?.role === 'coordinator';
  const isStudent = user?.role === 'student';

  const [company,          setCompany]          = useState(null);
  const [loading,          setLoading]          = useState(true);
  const [applying,         setApplying]         = useState(false);
  const [stageModalOpen,   setStageModalOpen]   = useState(false);
  const [timelineExpanded, setTimelineExpanded] = useState(false);
  const [savingBookmark, setSavingBookmark] = useState(false);

  const savedCompanyIds = new Set((user?.savedCompanies || []).map(String));
  const isSaved = savedCompanyIds.has(String(company?._id));

  const fetchCompany = async () => {
    try {
      const res = await companyService.getById(id);
      setCompany(res.data.company);
    } catch {
      toast.error('Company not found');
      navigate(-1);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchCompany(); }, [id]);

  const handleDelete = async () => {
    if (!window.confirm(`Remove ${company.name} from active companies?`)) return;
    try {
      await companyService.remove(id);
      toast.success('Company removed');
      navigate('/coordinator/companies');
    } catch { toast.error('Failed to remove company'); }
  };

  const handleStageUpdated = (updatedCompany) => {
    setCompany(updatedCompany);
    setStageModalOpen(false);
    toast.success(`Stage updated to ${updatedCompany.currentStage}`);
  };

  const toggleBookmark = async () => {
    if (!company?._id || savingBookmark) return;
    setSavingBookmark(true);
    try {
      const res = await authService.toggleSavedCompany(company._id);
      if (Array.isArray(res.data?.savedCompanyIds)) {
        updateUser({ savedCompanies: res.data.savedCompanyIds });
      }
      toast.success(res.message || (res.data?.saved ? 'Company saved' : 'Company removed from saved list'));
    } catch {
      toast.error('Could not update saved companies');
    } finally {
      setSavingBookmark(false);
    }
  };

  const handleApply = async () => {
    if (!company?._id || applying) return;

    setApplying(true);
    try {
      await applicationService.apply(company._id);
      navigate('/student/applications', {
        state: {
          applyToast: 'Application submitted!',
          applyToastType: 'success',
          appliedCompanyId: company._id,
        },
      });
    } catch (err) {
      if (err.response?.status === 409) {
        navigate('/student/applications', {
          state: {
            applyToast: 'You have already applied to this company',
            applyToastType: 'error',
            appliedCompanyId: company._id,
          },
        });
        return;
      }

      toast.error(err.response?.data?.message || 'Failed to apply');
    } finally {
      setApplying(false);
    }
  };

  if (loading) return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: 'clamp(16px,4vw,24px)' }}>
      <CompanyDetailSkeleton />
    </div>
  );
  if (!company) return null;

  const stage = getStage(company.currentStage);

  const formatCTC = (ctc) => {
    if (!ctc?.min && !ctc?.max) return 'Not disclosed';
    if (ctc.min === ctc.max)    return `₹${ctc.max} LPA`;
    return `₹${ctc.min} – ${ctc.max} LPA`;
  };

  return (
    <div
      className="page-enter"
      style={{ maxWidth: 960, margin: '0 auto', padding: 'clamp(16px,4vw,24px)', display: 'flex', flexDirection: 'column', gap: 16 }}
    >
      {/* ── Back ───────────────────────────────────────────────────── */}
      <button
        onClick={() => navigate(-1)}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 7, fontSize: 13, fontWeight: 500, color: 'var(--text-muted)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, transition: 'color 0.15s ease', alignSelf: 'flex-start' }}
        onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
        onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
      >
        <ArrowLeft size={15} /> Back to companies
      </button>

      {/* ── Hero card ──────────────────────────────────────────────── */}
      <Card style={{ padding: 'clamp(18px,3vw,26px)' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 20 }}>
          <CompanyLogo logo={company.logo} name={company.name} size="lg" />

          <div style={{ flex: 1, minWidth: 0 }}>
            {/* Name + actions */}
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
              <div>
                <h1 style={{ fontSize: 'clamp(20px,3vw,28px)', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
                  {company.name}
                </h1>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', marginTop: 4 }}>
                  <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{company.sector}</span>
                  <span style={{ color: 'var(--border)' }}>·</span>
                  <span style={{ fontSize: 13, textTransform: 'capitalize', color: 'var(--text-muted)' }}>{company.type}</span>
                  {company.location && (
                    <>
                      <span style={{ color: 'var(--border)' }}>·</span>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--text-muted)' }}>
                        <MapPin size={11} /> {company.location}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Coordinator actions */}
              {(isCoordinator || isStudent) && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {isStudent && (
                    <button
                      onClick={toggleBookmark}
                      disabled={savingBookmark}
                      style={{
                        display: 'inline-flex', alignItems: 'center', gap: 6,
                        padding: '9px 16px', borderRadius: 'var(--radius-input)',
                        background: isSaved ? 'rgba(10,132,255,0.10)' : 'transparent',
                        color: isSaved ? 'var(--accent)' : 'var(--text-secondary)',
                        fontWeight: 700, fontSize: 13, border: '1px solid var(--border)', cursor: 'pointer',
                        transition: 'background 0.18s ease, transform 0.18s ease',
                        opacity: savingBookmark ? 0.7 : 1,
                      }}
                    >
                      {isSaved ? <BookmarkCheck size={14} /> : <Bookmark size={14} />}
                      {isSaved ? 'Saved' : 'Save'}
                    </button>
                  )}
                  {isCoordinator && (
                  <button
                    onClick={() => setStageModalOpen(true)}
                    style={{
                      display: 'inline-flex', alignItems: 'center', gap: 6,
                      padding: '9px 16px', borderRadius: 'var(--radius-input)',
                      background: 'var(--accent)', color: '#fff',
                      fontWeight: 700, fontSize: 13, border: 'none', cursor: 'pointer',
                      transition: 'background 0.18s ease, transform 0.18s ease',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-hover)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                    onMouseLeave={e => { e.currentTarget.style.background = 'var(--accent)';        e.currentTarget.style.transform = 'translateY(0)'; }}
                  >
                    Update Stage
                  </button>
                  )}
                  {isCoordinator && <IconBtn as={Link} to={`/coordinator/companies/${id}/edit`} title="Edit"><Edit size={15} /></IconBtn>}
                  {isCoordinator && <IconBtn onClick={handleDelete} title="Delete" danger><Trash2 size={15} /></IconBtn>}
                </div>
              )}
            </div>

            {/* Stage + deadline row */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 16, flexWrap: 'wrap' }}>
              {/* Stage pill */}
              <span style={{
                display:     'inline-flex', alignItems: 'center', gap: 6,
                fontSize:    11, fontWeight: 700,
                padding:     '5px 12px',
                borderRadius: 'var(--radius-pill)',
                background:  stage.bg,
                border:      `1px solid ${stage.border || 'var(--border)'}`,
                color:       stage.color,
              }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor', animation: 'pulse 2s infinite' }} />
                {stage.label}
              </span>

              {company.applicationDeadline && (
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text-muted)' }}>
                  <Calendar size={11} />
                  Deadline: {new Date(company.applicationDeadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
                  <Countdown deadline={company.applicationDeadline} />
                </div>
              )}

              {company.websiteUrl && (
                <a
                  href={company.websiteUrl} target="_blank" rel="noopener noreferrer"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--accent)', fontWeight: 600, textDecoration: 'none', transition: 'opacity 0.15s ease' }}
                  onMouseEnter={e => e.currentTarget.style.opacity = '0.75'}
                  onMouseLeave={e => e.currentTarget.style.opacity = '1'}
                >
                  <Globe size={11} /> Website <ExternalLink size={10} />
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Description */}
        {company.description && (
          <p style={{ marginTop: 18, paddingTop: 18, borderTop: '1px solid var(--border)', fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
            {company.description}
          </p>
        )}
      </Card>

      {/* ── Stage pipeline ─────────────────────────────────────────── */}
      <Card style={{ padding: '20px 22px' }}>
        <CardHeading icon={Clock} iconBg="rgba(10,132,255,0.10)" iconColor="var(--accent)">
          Recruitment Pipeline
        </CardHeading>
        <StagePipeline currentStage={company.currentStage} />
      </Card>

      {/* ── Main grid ──────────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: 16, alignItems: 'start' }}
        className="md:grid-cols-[2fr_1fr] grid-cols-1">

        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Open roles */}
          {company.roles?.length > 0 && (
            <Card style={{ padding: '20px 22px' }}>
              <CardHeading>Open Roles</CardHeading>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {company.roles.map(r => (
                  <span key={r} style={{
                    fontSize: 13, fontWeight: 500,
                    padding: '6px 14px', borderRadius: 'var(--radius-pill)',
                    background: 'rgba(10,132,255,0.10)',
                    border: '1px solid rgba(10,132,255,0.2)',
                    color: 'var(--accent)',
                  }}>
                    {r}
                  </span>
                ))}
              </div>
            </Card>
          )}

          {/* Documents */}
          {company.documents?.length > 0 && (
            <Card style={{ padding: '20px 22px' }}>
              <CardHeading icon={FileText} iconBg="rgba(10,132,255,0.10)" iconColor="var(--accent)">
                Documents
              </CardHeading>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {company.documents.map((doc, i) => (
                  <a
                    key={i} href={doc.url} target="_blank" rel="noopener noreferrer"
                    style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '11px 14px', borderRadius: 'var(--radius-input)',
                      border: '1px solid var(--border)', textDecoration: 'none',
                      background: 'var(--surface-2)',
                      transition: 'border-color 0.15s ease, background 0.15s ease',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(10,132,255,0.3)'; e.currentTarget.style.background = 'var(--surface)'; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--surface-2)'; }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <FileText size={14} style={{ color: 'var(--accent)' }} />
                      <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{doc.name}</span>
                    </div>
                    <ExternalLink size={12} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
                  </a>
                ))}
              </div>
            </Card>
          )}

          {/* Timeline */}
          <Card style={{ padding: '20px 22px' }}>
            <CardHeading
              icon={Clock}
              iconBg="rgba(255,159,10,0.10)"
              iconColor="var(--warning)"
              action={company.timeline?.length > 3 && (
                <button
                  onClick={() => setTimelineExpanded(p => !p)}
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, fontWeight: 600, color: 'var(--accent)', background: 'none', border: 'none', cursor: 'pointer' }}
                >
                  {timelineExpanded
                    ? <><ChevronUp size={13} /> Show less</>
                    : <><ChevronDown size={13} /> Show all ({company.timeline.length})</>
                  }
                </button>
              )}
            >
              Timeline History
            </CardHeading>

            <div style={{ display: 'flex', flexDirection: 'column' }}>
              {(timelineExpanded ? company.timeline : company.timeline?.slice(-3))
                ?.slice().reverse()
                .map((entry, i, arr) => (
                  <TimelineEntry key={entry._id} entry={entry} isLast={i === arr.length - 1} />
                ))}
            </div>
          </Card>
        </div>

        {/* Right sidebar */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Key details */}
          <Card style={{ padding: '18px 20px' }}>
            <CardHeading>Key Details</CardHeading>
            <div>
              <InfoRow icon={IndianRupee} label="CTC Package"          value={formatCTC(company.ctc)} />
              <InfoRow icon={Users}       label="CGPA Cutoff"           value={company.eligibility?.cgpa > 0 ? `${company.eligibility.cgpa}+` : null} />
              <InfoRow icon={FileText}    label="Backlog Policy"        value={company.eligibility?.backlogs !== undefined ? `${company.eligibility.backlogs} backlogs allowed` : null} />
              <InfoRow icon={Calendar}    label="Application Deadline"  value={company.applicationDeadline ? new Date(company.applicationDeadline).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' }) : null} />
            </div>
          </Card>

          {/* Eligible branches */}
          {company.eligibility?.branches?.length > 0 && (
            <Card style={{ padding: '18px 20px' }}>
              <CardHeading>Eligible Branches</CardHeading>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {company.eligibility.branches.map(b => (
                  <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-secondary)' }}>
                    <CheckCircle size={13} style={{ color: 'var(--status-success)', flexShrink: 0 }} /> {b}
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Student CTA */}
          {user?.role === 'student' && company.currentStage !== 'closed' && (
            <div style={{
              background:   'rgba(10,132,255,0.06)',
              border:       '1px solid rgba(10,132,255,0.2)',
              borderRadius: 'var(--radius-card)',
              padding:      '18px 20px',
              borderLeft:   '3px solid var(--accent)',
            }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>Interested?</h3>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 14, lineHeight: 1.55 }}>
                Apply to track your status across all rounds.
              </p>
              <button
                type="button"
                onClick={handleApply}
                disabled={applying}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  width: '100%', padding: '10px 0', borderRadius: 'var(--radius-input)',
                  background: applying ? 'var(--accent-soft)' : 'var(--accent)', color: '#fff',
                  fontWeight: 700, fontSize: 13, textDecoration: 'none',
                  transition: 'background 0.18s ease',
                  boxSizing: 'border-box', border: 'none', cursor: applying ? 'wait' : 'pointer',
                  opacity: applying ? 0.8 : 1,
                }}
                onMouseEnter={e => {
                  if (!applying) e.currentTarget.style.background = 'var(--accent-hover)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.background = applying ? 'var(--accent-soft)' : 'var(--accent)';
                }}
              >
                {applying ? 'Applying...' : 'Apply Now'}
              </button>
              <Link
                to={`/student/ai-prep?company=${company._id}`}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                  width: '100%', padding: '9px 0', marginTop: 8,
                  borderRadius: 'var(--radius-input)',
                  border: '1px solid rgba(10,132,255,0.3)',
                  background: 'transparent',
                  color: 'var(--accent)',
                  fontWeight: 600, fontSize: 13, textDecoration: 'none',
                  transition: 'background 0.15s ease',
                  boxSizing: 'border-box',
                }}
                onMouseEnter={e => e.currentTarget.style.background = 'rgba(10,132,255,0.08)'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <BrainCircuit size={13} /> AI Interview Prep
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* ── Update stage modal ─────────────────────────────────────── */}
      {isCoordinator && (
        <UpdateStageModal
          isOpen={stageModalOpen}
          onClose={() => setStageModalOpen(false)}
          company={company}
          onUpdated={handleStageUpdated}
        />
      )}
    </div>
  );
};

export default CompanyDetailPage;
