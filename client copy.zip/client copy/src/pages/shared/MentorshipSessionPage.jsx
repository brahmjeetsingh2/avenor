import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { CalendarCheck2, Check, Clock, MessageSquare, Target, X } from 'lucide-react';
import toast from 'react-hot-toast';
import mentorshipService from '../../services/mentorshipService';
import useAuth from '../../hooks/useAuth';
import Button from '../../components/ui/Button';

const MentorshipSessionPage = () => {
  const { id } = useParams();
  const { user } = useAuth();

  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updateText, setUpdateText] = useState('');
  const [targetDate, setTargetDate] = useState('');

  const isAlumni = user?.role === 'alumni';
  const isStudent = user?.role === 'student';

  const load = async () => {
    setLoading(true);
    try {
      const res = await mentorshipService.getById(id);
      const req = res.data.request;
      setRequest(req);
      if (req?.session?.targetDate) {
        setTargetDate(new Date(req.session.targetDate).toISOString().slice(0, 10));
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to load mentorship session');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [id]);

  const counterpart = useMemo(() => (isAlumni ? request?.student : request?.alumni), [isAlumni, request]);

  const updateStatus = async (status) => {
    try {
      await mentorshipService.updateStatus(id, {
        status,
        targetDate: status === 'accepted' ? targetDate : undefined,
      });
      toast.success(`Mentorship ${status}`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not update status');
    }
  };

  const cancel = async () => {
    try {
      await mentorshipService.cancel(id);
      toast.success('Request cancelled');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not cancel request');
    }
  };

  const toggleMilestone = async (milestone) => {
    const next = milestone.status === 'completed' ? 'pending' : 'completed';
    try {
      await mentorshipService.updateMilestone(id, milestone._id, { status: next });
      toast.success('Milestone updated');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not update milestone');
    }
  };

  const addUpdate = async () => {
    if (!updateText.trim()) return;
    try {
      await mentorshipService.addUpdate(id, { message: updateText.trim() });
      setUpdateText('');
      toast.success('Update posted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not post update');
    }
  };

  if (loading || !request) {
    return <div className="max-w-5xl mx-auto p-6"><div className="card p-8 text-sm">Loading mentorship session...</div></div>;
  }

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6 page-enter space-y-5">
      <div className="card p-5 bg-gradient-to-r from-cyan-500/14 via-coral-500/10 to-gold-500/10 border-cyan-500/28 shadow-[0_20px_48px_-38px_rgba(11,162,213,.92)]">
        <h1 className="font-display text-2xl font-bold text-[var(--color-text-primary)]">Mentorship Session</h1>
        <p className="text-sm text-[var(--color-text-muted)] mt-1">
          {request.topic.replace('_', ' ')} · with {counterpart?.name || 'Participant'} · status {request.status}
        </p>
        <div className="mt-3 text-sm text-[var(--color-text-secondary)]">
          <p>{request.message}</p>
          {request.preferredTime ? <p className="mt-1 inline-flex items-center gap-1 text-xs text-[var(--color-text-muted)]"><Clock size={12} /> Preferred: {request.preferredTime}</p> : null}
        </div>
      </div>

      {request.session?.isActive ? (
        <div className="rounded-xl border border-coral-500/30 bg-coral-500/12 p-4">
          <p className="font-semibold text-coral-600 inline-flex items-center gap-2"><CalendarCheck2 size={16} /> Session Active</p>
          <p className="text-sm text-lime-700 mt-1">Progress {request.sessionProgress?.completed || 0}/{request.sessionProgress?.total || 0} ({request.sessionProgress?.percent || 0}%)</p>
          {request.session?.targetDate ? <p className="text-xs text-lime-700 mt-1">Target: {new Date(request.session.targetDate).toLocaleDateString('en-IN')}</p> : null}
        </div>
      ) : null}

      <div className="grid lg:grid-cols-2 gap-5">
        <div className="card p-4 space-y-3">
          <h2 className="font-display font-bold text-base inline-flex items-center gap-2"><Target size={15} /> Milestones</h2>
          {request.session?.milestones?.length ? request.session.milestones.map((m) => (
            <button
              key={m._id}
              type="button"
              onClick={() => isAlumni && request.session?.isActive ? toggleMilestone(m) : null}
              className={`w-full text-left rounded-xl border p-3 text-sm ${m.status === 'completed' ? 'border-coral-500/30 bg-coral-500/12' : 'border-[var(--color-border)]'}`}
            >
              <span className="font-semibold">{m.title}</span>
              <span className="ml-2 text-xs text-[var(--color-text-muted)]">{m.status}</span>
            </button>
          )) : <p className="text-sm text-[var(--color-text-muted)]">Milestones will appear once session is accepted.</p>}
        </div>

        <div className="card p-4 space-y-3">
          <h2 className="font-display font-bold text-base inline-flex items-center gap-2"><MessageSquare size={15} /> Session Timeline</h2>
          {request.session?.updates?.length ? (
            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {request.session.updates.map((u, idx) => (
                <div key={`${u.createdAt || idx}-${idx}`} className="rounded-xl border border-[var(--color-border)] p-3 text-sm">
                  <p><span className="font-semibold capitalize">{u.actorRole}</span>: {u.message}</p>
                  <p className="text-xs text-[var(--color-text-muted)] mt-1">{u.by?.name || 'User'} · {u.createdAt ? new Date(u.createdAt).toLocaleString('en-IN') : ''}</p>
                </div>
              ))}
            </div>
          ) : <p className="text-sm text-[var(--color-text-muted)]">No updates yet.</p>}

          <div className="flex gap-2 pt-1">
            <input className="input" placeholder="Post an update" value={updateText} onChange={(e) => setUpdateText(e.target.value)} />
            <Button size="sm" onClick={addUpdate}>Add</Button>
          </div>
        </div>
      </div>

      <div className="card p-4 flex flex-wrap gap-2">
        {isAlumni && request.status === 'pending' ? (
          <>
            <input className="input max-w-56" type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} />
            <Button size="sm" leftIcon={<Check size={13} />} onClick={() => updateStatus('accepted')}>Accept & Activate</Button>
            <Button size="sm" variant="secondary" leftIcon={<X size={13} />} onClick={() => updateStatus('declined')}>Decline</Button>
          </>
        ) : null}

        {isAlumni && request.status === 'accepted' ? (
          <Button size="sm" leftIcon={<Check size={13} />} onClick={() => updateStatus('completed')}>Mark Completed</Button>
        ) : null}

        {isStudent && ['pending', 'accepted'].includes(request.status) ? (
          <Button size="sm" variant="secondary" leftIcon={<X size={13} />} onClick={cancel}>Cancel Request</Button>
        ) : null}
      </div>
    </div>
  );
};

export default MentorshipSessionPage;
