import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, LayoutGrid, List, Building2 } from 'lucide-react';
import toast from 'react-hot-toast';
import companyService from '../../services/companyService';
import useAuth from '../../hooks/useAuth';
import CompanyCard from '../../components/shared/CompanyCard';
import CompanyFilters from '../../components/shared/CompanyFilters';
import { CompanyCardSkeleton } from '../../components/shared/Skeleton';

const EMPTY_FILTERS = { stage: '', sector: '', type: '', ctcMin: '', ctcMax: '', branch: '' };

// ─── Empty state ──────────────────────────────────────────────────────────────
const EmptyState = ({ hasFilters, onClear, isCoordinator, onCreate }) => (
  <div style={{ gridColumn: '1 / -1', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '72px 24px', textAlign: 'center' }}>
    <div style={{ width: 60, height: 60, borderRadius: 16, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 18 }}>
      <Building2 size={26} style={{ color: 'var(--text-muted)' }} />
    </div>
    <h3 style={{ fontSize: 18, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>
      {hasFilters ? 'No companies match your filters' : 'No companies yet'}
    </h3>
    <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 22, maxWidth: 320, lineHeight: 1.65 }}>
      {hasFilters
        ? 'Try adjusting your filters to see more results.'
        : isCoordinator
          ? 'Add the first company to kick off placement season.'
          : 'Your placement coordinator will add companies soon.'}
    </p>
    {hasFilters && (
      <button
        onClick={onClear}
        style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent)', background: 'none', border: 'none', cursor: 'pointer' }}
        onMouseEnter={e => e.currentTarget.style.opacity = '0.75'}
        onMouseLeave={e => e.currentTarget.style.opacity = '1'}
      >
        Clear all filters
      </button>
    )}
    {!hasFilters && isCoordinator && (
      <button
        onClick={onCreate}
        style={{
          display:      'inline-flex', alignItems: 'center', gap: 8,
          padding:      '10px 20px',
          background:   'var(--accent)', color: '#fff',
          fontWeight:   700, fontSize: 13,
          borderRadius: 'var(--radius-input)',
          border:       'none', cursor: 'pointer',
          transition:   'background 0.18s ease',
        }}
        onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
        onMouseLeave={e => e.currentTarget.style.background = 'var(--accent)'}
      >
        <Plus size={15} /> Add First Company
      </button>
    )}
  </div>
);

// ─── Main page ────────────────────────────────────────────────────────────────
const CompaniesPage = () => {
  const navigate      = useNavigate();
  const { user }      = useAuth();
  const isCoordinator = user?.role === 'coordinator';

  const [companies,    setCompanies]   = useState([]);
  const [loading,      setLoading]     = useState(true);
  const [search,       setSearch]      = useState('');
  const [filters,      setFilters]     = useState(EMPTY_FILTERS);
  const [page,         setPage]        = useState(1);
  const [pagination,   setPagination]  = useState({});
  const [view,         setView]        = useState('grid');
  const [filtersOpen,  setFiltersOpen] = useState(false);
  const [searchInput,  setSearchInput] = useState('');

  const hasFilters = Object.values(filters).some(Boolean) || search;

  const fetchCompanies = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 12, search, ...filters };
      Object.keys(params).forEach(k => !params[k] && delete params[k]);
      const res = await companyService.getAll(params);
      setCompanies(res.data);
      setPagination(res.pagination);
    } catch {
      toast.error('Failed to load companies');
    } finally {
      setLoading(false);
    }
  }, [page, search, filters]);

  useEffect(() => { fetchCompanies(); }, [fetchCompanies]);

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => { setSearch(searchInput); setPage(1); }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  const handleFilterChange = (newFilters) => { setFilters(newFilters); setPage(1); };
  const handleClearFilters = () => { setFilters(EMPTY_FILTERS); setSearch(''); setSearchInput(''); setPage(1); };

  return (
    <div style={{ display: 'flex', height: 'calc(100vh - 4rem)', overflow: 'hidden' }}>

      {/* ── Filters sidebar (desktop) ───────────────────────────────── */}
      <aside
        className="hidden lg:block"
        style={{
          width:        256,
          flexShrink:   0,
          borderRight:  '1px solid var(--border)',
          overflowY:    'auto',
          padding:      20,
          background:   'var(--surface)',
        }}
      >
        <CompanyFilters filters={filters} onChange={handleFilterChange} onClear={handleClearFilters} />
      </aside>

      {/* ── Main content ────────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Topbar */}
        <div
          style={{
            display:      'flex',
            alignItems:   'center',
            gap:          10,
            padding:      '12px 16px',
            borderBottom: '1px solid var(--border)',
            background:   'var(--surface)',
            flexShrink:   0,
          }}
        >
          {/* Search */}
          <div style={{ position: 'relative', flex: 1, maxWidth: 320 }}>
            <Search size={14} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)', pointerEvents: 'none' }} />
            <input
              type="text"
              placeholder="Search companies…"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              style={{
                width:        '100%',
                height:       38,
                paddingLeft:  34,
                paddingRight: 12,
                borderRadius: 'var(--radius-input)',
                border:       '1px solid var(--border)',
                background:   'var(--surface-2)',
                color:        'var(--text-primary)',
                fontSize:     13,
                outline:      'none',
                boxSizing:    'border-box',
                transition:   'border-color 0.18s ease, box-shadow 0.18s ease',
              }}
              onFocus={e => { e.target.style.borderColor = 'var(--accent)'; e.target.style.boxShadow = '0 0 0 3px rgba(10,132,255,0.15)'; }}
              onBlur={e  => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = 'none'; }}
            />
          </div>

          {/* Mobile filter toggle */}
          <button
            onClick={() => setFiltersOpen(p => !p)}
            className="lg:hidden"
            style={{
              display:      'inline-flex', alignItems: 'center', gap: 6,
              padding:      '7px 14px', fontSize: 13, fontWeight: 600,
              borderRadius: 'var(--radius-input)',
              border:       `1px solid ${filtersOpen || hasFilters ? 'rgba(10,132,255,0.35)' : 'var(--border)'}`,
              background:   filtersOpen || hasFilters ? 'rgba(10,132,255,0.08)' : 'transparent',
              color:        filtersOpen || hasFilters ? 'var(--accent)' : 'var(--text-secondary)',
              cursor:       'pointer',
              transition:   'all 0.15s ease',
            }}
          >
            Filters
            {hasFilters && <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', display: 'inline-block' }} />}
          </button>

          {/* Right side: count + view toggle + add button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginLeft: 'auto' }}>
            <span className="hidden sm:block" style={{ fontSize: 12, color: 'var(--text-muted)' }}>
              {pagination.total ?? 0} companies
            </span>

            {/* View toggle */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: 3, borderRadius: 8, background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
              {[{ id: 'grid', icon: LayoutGrid }, { id: 'list', icon: List }].map(({ id, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setView(id)}
                  style={{
                    padding:    '5px 7px',
                    borderRadius: 6,
                    border:     'none',
                    cursor:     'pointer',
                    background: view === id ? 'var(--surface)' : 'transparent',
                    color:      view === id ? 'var(--accent)'  : 'var(--text-muted)',
                    boxShadow:  view === id ? 'var(--shadow-soft)' : 'none',
                    transition: 'all 0.15s ease',
                  }}
                >
                  <Icon size={14} />
                </button>
              ))}
            </div>

            {/* Coordinator add button */}
            {isCoordinator && (
              <button
                onClick={() => navigate('/coordinator/companies/new')}
                style={{
                  display:      'inline-flex', alignItems: 'center', gap: 7,
                  padding:      '7px 14px',
                  background:   'var(--accent)', color: '#fff',
                  fontWeight:   700, fontSize: 13,
                  borderRadius: 'var(--radius-input)',
                  border:       'none', cursor: 'pointer',
                  boxShadow:    '0 0 18px rgba(10,132,255,0.28)',
                  transition:   'background 0.18s ease, transform 0.18s ease',
                }}
                onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-hover)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
                onMouseLeave={e => { e.currentTarget.style.background = 'var(--accent)';        e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                <Plus size={14} /> Add Company
              </button>
            )}
          </div>
        </div>

        {/* Mobile filters drawer */}
        {filtersOpen && (
          <div
            className="lg:hidden animate-slide-down"
            style={{ borderBottom: '1px solid var(--border)', padding: '14px 16px', background: 'var(--surface)' }}
          >
            <CompanyFilters filters={filters} onChange={handleFilterChange} onClear={handleClearFilters} />
          </div>
        )}

        {/* Cards area */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 'clamp(14px,3vw,24px)' }}>
          <div style={{
            display:             'grid',
            gap:                 16,
            gridTemplateColumns: view === 'grid'
              ? 'repeat(auto-fill, minmax(280px, 1fr))'
              : '1fr',
            maxWidth:            view === 'list' ? 800 : 'none',
          }}>
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <CompanyCardSkeleton key={i} />)
              : companies.length === 0
                ? <EmptyState
                    hasFilters={hasFilters}
                    onClear={handleClearFilters}
                    isCoordinator={isCoordinator}
                    onCreate={() => navigate('/coordinator/companies/new')}
                  />
                : companies.map(c => (
                    <CompanyCard
                      key={c._id}
                      company={c}
                      showApply={user?.role === 'student'}
                      onApply={company => navigate(`/companies/${company._id}`)}
                    />
                  ))
            }
          </div>

          {/* Pagination */}
          {pagination.pages > 1 && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 32 }}>
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                style={{
                  padding:      '8px 18px',
                  borderRadius: 'var(--radius-input)',
                  border:       '1px solid var(--border)',
                  background:   'var(--surface)',
                  color:        'var(--text-secondary)',
                  fontSize:     13, fontWeight: 600,
                  cursor:       page === 1 ? 'not-allowed' : 'pointer',
                  opacity:      page === 1 ? 0.4 : 1,
                  transition:   'border-color 0.15s ease',
                }}
                onMouseEnter={e => { if (page !== 1) e.currentTarget.style.borderColor = 'rgba(10,132,255,0.35)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; }}
              >
                Previous
              </button>

              <span style={{ fontSize: 13, color: 'var(--text-muted)', padding: '0 4px' }}>
                {page} / {pagination.pages}
              </span>

              <button
                disabled={page === pagination.pages}
                onClick={() => setPage(p => p + 1)}
                style={{
                  padding:      '8px 18px',
                  borderRadius: 'var(--radius-input)',
                  border:       '1px solid var(--border)',
                  background:   'var(--surface)',
                  color:        'var(--text-secondary)',
                  fontSize:     13, fontWeight: 600,
                  cursor:       page === pagination.pages ? 'not-allowed' : 'pointer',
                  opacity:      page === pagination.pages ? 0.4 : 1,
                  transition:   'border-color 0.15s ease',
                }}
                onMouseEnter={e => { if (page !== pagination.pages) e.currentTarget.style.borderColor = 'rgba(10,132,255,0.35)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; }}
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CompaniesPage;