import React, { useState, useEffect } from 'react';
import { Sun, Moon, Bell, Shield, Trash2, LogOut, Monitor } from 'lucide-react';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import useTheme from '../../hooks/useTheme';
import useAuth from '../../hooks/useAuth';
import Modal from '../../components/ui/Modal';

// ─── Theme store needs system mode support ────────────────────────────────────
const getSystemPreference = () =>
  window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';

const SettingRow = ({ icon: Icon, label, description, children, danger }) => (
  <div className="flex items-center justify-between py-4 border-b border-[var(--color-border)] last:border-0">
    <div className="flex items-start gap-3">
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5
        ${danger ? 'bg-[var(--role-coral-tint)] text-[var(--role-coral)]' : 'bg-[var(--color-border)] text-[var(--color-text-muted)]'}`}>
        <Icon size={15} />
      </div>
      <div>
        <p className={`text-sm font-semibold ${danger ? 'text-[var(--role-coral)]' : 'text-[var(--color-text-primary)]'}`}>
          {label}
        </p>
        {description && (
          <p className="text-xs text-[var(--color-text-muted)] mt-0.5">{description}</p>
        )}
      </div>
    </div>
    <div className="shrink-0 ml-4">{children}</div>
  </div>
);

const Toggle = ({ enabled, onChange }) => (
  <button
    onClick={() => onChange(!enabled)}
    className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5
      ${enabled ? 'bg-[var(--role-cyan)]' : 'bg-[var(--color-border)]'}`}
  >
    <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform
      ${enabled ? 'translate-x-5' : 'translate-x-0'}`}
    />
  </button>
);

// ─── Reusable modal confirm button row ────────────────────────────────────────
const ModalActions = ({ onCancel, onConfirm, confirmLabel, loading, variant = 'danger' }) => (
  <div className="flex items-center gap-3 w-full">
    <button
      onClick={onCancel}
      className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold border-2 border-[var(--color-border)] text-[var(--color-text-secondary)] bg-[var(--color-card)] hover:bg-[var(--color-border)] hover:text-[var(--color-text-primary)] transition-all"
    >
      Cancel
    </button>
    <button
      onClick={onConfirm}
      disabled={loading}
      className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-bold text-white transition-all disabled:opacity-60
        ${variant === 'danger'
          ? 'bg-[var(--role-coral)] hover:bg-[var(--role-coral-deep)] border-2 border-[var(--role-coral)] hover:border-[var(--role-coral-deep)]'
          : 'bg-[var(--role-cyan)] hover:bg-[var(--role-cyan-deep)] border-2 border-[var(--role-cyan)]'
        }`}
    >
      {loading ? (
        <span className="flex items-center justify-center gap-2">
          <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          Please wait…
        </span>
      ) : confirmLabel}
    </button>
  </div>
);

const SettingsPage = () => {
  const { theme, toggleTheme, isDark } = useTheme();
  const { user, logoutUser } = useAuth();
  const navigate = useNavigate();

  // System theme: track if user chose system mode
  const [themeMode, setThemeMode] = useState(() => {
    return localStorage.getItem('hiretrack-theme-mode') || (isDark ? 'dark' : 'light');
  });

  const handleThemeSelect = (mode) => {
    setThemeMode(mode);
    localStorage.setItem('hiretrack-theme-mode', mode);

    if (mode === 'system') {
      const sysPref = getSystemPreference();
      // Apply system preference
      if (sysPref === 'dark' && !isDark) toggleTheme();
      if (sysPref === 'light' && isDark) toggleTheme();
      // Listen for system changes
    } else if (mode === 'dark' && !isDark) {
      toggleTheme();
    } else if (mode === 'light' && isDark) {
      toggleTheme();
    }
  };

  // Listen for system preference changes when in system mode
  useEffect(() => {
    if (themeMode !== 'system') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e) => {
      if (e.matches && !isDark) toggleTheme();
      if (!e.matches && isDark) toggleTheme();
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [themeMode, isDark, toggleTheme]);

  const [notifSettings, setNotifSettings] = useState({
    statusUpdates:  true,
    announcements:  true,
    newExperiences: false,
    offers:         true,
  });

  const [logoutModal, setLogoutModal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [loggingOut,  setLoggingOut]  = useState(false);

  const setNotif = (key, val) => setNotifSettings(p => ({ ...p, [key]: val }));

  const handleLogout = async () => {
    setLoggingOut(true);
    await logoutUser();
    toast.success('Signed out successfully');
    navigate('/');
  };

  const handleDeleteAccount = () => {
    toast.error('Account deletion requires contacting support.');
    setDeleteModal(false);
  };

  const roleColors = {
    student: 'bg-[var(--role-cyan-tint)] text-[var(--role-cyan)]',
    coordinator: 'bg-[var(--role-gold-tint)] text-[var(--role-gold)]',
    alumni: 'bg-[var(--role-coral-tint)] text-[var(--role-coral)]',
  };

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6 page-enter space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-[var(--color-text-primary)]">Settings</h1>
        <p className="text-sm text-[var(--color-text-muted)] mt-0.5">Manage your preferences</p>
      </div>

      {/* ── Appearance ─────────────────────────────────────────────── */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-sm text-[var(--color-text-primary)] uppercase tracking-wider mb-1">
          Appearance
        </h2>
        <p className="text-xs text-[var(--color-text-muted)] mb-4">Choose how HireTrack looks for you</p>

        <div className="grid grid-cols-3 gap-3">
          {[
            { id: 'light',  icon: Sun,     label: 'Light'  },
            { id: 'dark',   icon: Moon,    label: 'Dark'   },
            { id: 'system', icon: Monitor, label: 'System' },
          ].map(({ id, icon: Icon, label }) => {
            const isActive = themeMode === id;
            return (
              <button
                key={id}
                onClick={() => handleThemeSelect(id)}
                className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all duration-200
                  ${isActive
                    ? 'border-[var(--role-cyan)] bg-[var(--role-cyan-tint)]'
                    : 'border-[var(--color-border)] bg-[var(--color-card)] hover:border-[var(--role-cyan)] hover:bg-[var(--color-border)]'
                  }`}
              >
                <Icon
                  size={20}
                  className={isActive ? 'text-[var(--role-cyan)]' : 'text-[var(--color-text-muted)]'}
                />
                <span className={`text-xs font-semibold ${isActive ? 'text-[var(--role-cyan)]' : 'text-[var(--color-text-secondary)]'}`}>
                  {label}
                </span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[var(--role-cyan)]" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Notifications ──────────────────────────────────────────── */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-sm text-[var(--color-text-primary)] uppercase tracking-wider mb-1">
          Notifications
        </h2>
        <p className="text-xs text-[var(--color-text-muted)] mb-2">Choose what you get notified about</p>

        <SettingRow icon={Bell} label="Status Updates" description="When your application status changes">
          <Toggle enabled={notifSettings.statusUpdates} onChange={v => setNotif('statusUpdates', v)} />
        </SettingRow>
        <SettingRow icon={Bell} label="Announcements" description="Company announcements from coordinators">
          <Toggle enabled={notifSettings.announcements} onChange={v => setNotif('announcements', v)} />
        </SettingRow>
        <SettingRow icon={Bell} label="New Experiences" description="When seniors post new interview experiences">
          <Toggle enabled={notifSettings.newExperiences} onChange={v => setNotif('newExperiences', v)} />
        </SettingRow>
        <SettingRow icon={Bell} label="Offer Notifications" description="When you receive an offer">
          <Toggle enabled={notifSettings.offers} onChange={v => setNotif('offers', v)} />
        </SettingRow>
      </div>

      {/* ── Account ────────────────────────────────────────────────── */}
      <div className="card p-6">
        <h2 className="font-display font-bold text-sm text-[var(--color-text-primary)] uppercase tracking-wider mb-1">
          Account
        </h2>
        <p className="text-xs text-[var(--color-text-muted)] mb-2">Your account details</p>
        <SettingRow icon={Shield} label="Role" description={`Registered as ${user?.role}`}>
          <span className={`text-xs font-bold px-2.5 py-1 rounded-lg capitalize ${roleColors[user?.role] || roleColors.student}`}>
            {user?.role}
          </span>
        </SettingRow>
      </div>

      {/* ── Danger Zone ────────────────────────────────────────────── */}
      <div className="card p-6 border-[rgba(248,102,36,0.22)]">
        <h2 className="font-display font-bold text-sm text-[var(--role-coral)] uppercase tracking-wider mb-1">
          Danger Zone
        </h2>
        <p className="text-xs text-[var(--color-text-muted)] mb-2">Irreversible actions — proceed with caution</p>

        <SettingRow
          icon={LogOut}
          label="Sign Out"
          description="Sign out from this device"
          danger
        >
          <button
            onClick={() => setLogoutModal(true)}
            className="text-sm font-bold px-4 py-2 rounded-xl border-2 border-[var(--role-coral)] text-[var(--role-coral)] bg-transparent hover:bg-[var(--role-coral)] hover:text-[var(--text-reverse)] transition-all duration-200"
          >
            Sign Out
          </button>
        </SettingRow>

        <SettingRow
          icon={Trash2}
          label="Delete Account"
          description="Permanently delete all your data"
          danger
        >
          <button
            onClick={() => setDeleteModal(true)}
            className="text-sm font-bold px-4 py-2 rounded-xl border-2 border-[var(--role-coral)] text-[var(--role-coral)] bg-transparent hover:bg-[var(--role-coral)] hover:text-[var(--text-reverse)] transition-all duration-200"
          >
            Delete
          </button>
        </SettingRow>
      </div>

      {/* ── Sign Out Modal ──────────────────────────────────────────── */}
      <Modal
        isOpen={logoutModal}
        onClose={() => setLogoutModal(false)}
        title="Sign Out"
        size="sm"
        footer={
          <ModalActions
            onCancel={() => setLogoutModal(false)}
            onConfirm={handleLogout}
            confirmLabel="Yes, Sign Out"
            loading={loggingOut}
            variant="danger"
          />
        }
      >
        <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
          Are you sure you want to sign out of HireTrack?
        </p>
      </Modal>

      {/* ── Delete Account Modal ────────────────────────────────────── */}
      <Modal
        isOpen={deleteModal}
        onClose={() => setDeleteModal(false)}
        title="Delete Account"
        size="sm"
        footer={
          <ModalActions
            onCancel={() => setDeleteModal(false)}
            onConfirm={handleDeleteAccount}
            confirmLabel="Delete My Account"
            variant="danger"
          />
        }
      >
        <div className="space-y-3">
          <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">
            This will permanently delete your account, all applications, experiences, and salary data.
          </p>
          <div className="p-3 rounded-xl bg-[var(--role-coral-tint)] border border-[rgba(248,102,36,0.22)]">
            <p className="text-sm font-bold text-[var(--role-coral)]">⚠️ This action cannot be undone.</p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default SettingsPage;