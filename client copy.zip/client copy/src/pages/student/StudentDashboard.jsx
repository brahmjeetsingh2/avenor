import React, { useState, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Building2, FileText, BookOpen, BrainCircuit,
  ArrowRight, TrendingUp, Zap, Bell, Award, DollarSign,
  Bookmark, AlertTriangle, Clock3, RefreshCw, ClipboardList, PartyPopper,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';
import useAuth from '../../hooks/useAuth';
import applicationService from '../../services/applicationService';
import companyService from '../../services/companyService';
import experienceService from '../../services/experienceService';
import notificationService from '../../services/notificationService';
import referralService from '../../services/referralService';
import authService from '../../services/authService';
import { StatusBadge } from '../../utils/applicationStatus';
import { CompanyLogo } from '../../components/shared/CompanyCard';
import Countdown from '../../components/shared/Countdown';
import Avatar from '../../components/ui/Avatar';

// ─── Quick stat card ──────────────────────────────────────────────────────────
const QuickStat = ({ icon: Icon, label, value, iconBg, iconColor, hoverBorder = 'var(--role-cyan)', to }) => (
  <Link
    to={to}
    style={{
      display:        'flex',
      alignItems:     'center',
      gap:            14,
      padding:        '16px 18px',
      background:     'var(--surface)',
      border:         '1px solid var(--border)',
      borderRadius:   'var(--radius-card)',
      boxShadow:      'var(--shadow-soft)',
      textDecoration: 'none',
      transition:     'transform 0.2s cubic-bezier(0.2,0.8,0.2,1), box-shadow 0.2s ease, border-color 0.2s ease',
    }}
    onMouseEnter={e => {
      e.currentTarget.style.transform   = 'translateY(-2px)';
      e.currentTarget.style.boxShadow   = 'var(--shadow-hover)';
      e.currentTarget.style.borderColor = hoverBorder;
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform   = 'translateY(0)';
      e.currentTarget.style.boxShadow   = 'var(--shadow-soft)';
      e.currentTarget.style.borderColor = 'var(--border)';
    }}
  >
    {/* Icon */}
    <div style={{ width: 42, height: 42, borderRadius: 11, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: iconBg }}>
      <Icon size={18} style={{ color: iconColor }} />
    </div>

    {/* Text */}
    <div style={{ flex: 1 }}>
      <p style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', lineHeight: 1, letterSpacing: '-0.02em' }}>{value}</p>
      <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>{label}</p>
    </div>

    <ArrowRight size={14} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
  </Link>
);

// ─── Skeleton loader ──────────────────────────────────────────────────────────
const DashboardSkeleton = () => (
  <div style={{ padding: 'clamp(16px,4vw,24px)', display: 'flex', flexDirection: 'column', gap: 20 }}>
    <div className="skeleton" style={{ height: 96, borderRadius: 'var(--radius-card)' }} />
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 14 }}>
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="skeleton" style={{ height: 80, borderRadius: 'var(--radius-card)' }} />
      ))}
    </div>
  </div>
);

// ─── Section header ───────────────────────────────────────────────────────────
const SectionHeader = ({ title, to, linkLabel = 'View all' }) => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
    <h2 style={{ fontSize: 15, fontWeight: 600, color: 'var(--text-primary)' }}>{title}</h2>
    <Link
      to={to}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 13, fontWeight: 600, color: 'var(--accent)', textDecoration: 'none' }}
    >
      {linkLabel} <ArrowRight size={12} />
    </Link>
  </div>
);

const Panel = ({ title, children, action }) => (
  <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', overflow: 'hidden', boxShadow: 'var(--shadow-soft)' }}>
    <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
      <h2 style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{title}</h2>
      {action}
    </div>
    <div style={{ padding: 16 }}>
      {children}
    </div>
  </div>
);

// ─── Greeting ─────────────────────────────────────────────────────────────────
const greeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
};

// ─── Verdict pill (inline — for feed list) ────────────────────────────────────
const verdictStyle = {
  selected:   { background: 'var(--role-coral-tint)', color: 'var(--role-coral)' },
  rejected:   { background: 'var(--role-coral-tint)', color: 'var(--role-coral)' },
  waitlisted: { background: 'var(--role-gold-tint)',  color: 'var(--role-gold)' },
};

// ─── Main component ───────────────────────────────────────────────────────────
const StudentDashboard = () => {
  const { user }    = useAuth();
  const navigate    = useNavigate();
  const [apps,      setApps]      = useState([]);
  const [companies, setCompanies] = useState([]);
  const [companyCount, setCompanyCount] = useState(0);
  const [feed,      setFeed]      = useState([]);
  const [savedCompanies, setSavedCompanies] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [referrals, setReferrals] = useState([]);
  const [stats,     setStats]     = useState({ stats: [], total: 0 });
  const [loading,   setLoading]   = useState(true);

  useEffect(() => {
    Promise.allSettled([
      applicationService.getMyApps(),
      applicationService.getMyStats(),
      companyService.getAll({ limit: 20, active: 'true', sortBy: 'createdAt', order: 'desc' }),
      experienceService.getFeed({ limit: 3 }),
      notificationService.getAll({ limit: 8 }),
      referralService.list({ limit: 8, sort: 'newest' }),
      authService.getSavedCompanies(),
    ]).then(([appsRes, statsRes, compRes, feedRes, notifRes, referralRes, savedRes]) => {
      const appsData = appsRes.status === 'fulfilled' ? (appsRes.value.data?.data ?? appsRes.value.data) : null;
      const statsData = statsRes.status === 'fulfilled' ? (statsRes.value.data?.data ?? statsRes.value.data) : null;
      const companiesData = compRes.status === 'fulfilled'
        ? (Array.isArray(compRes.value?.data) ? compRes.value.data : (Array.isArray(compRes.value) ? compRes.value : []))
        : [];
      const feedData = feedRes.status === 'fulfilled' ? (feedRes.value.data ?? feedRes.value) : null;
      const notifData = notifRes.status === 'fulfilled' ? (notifRes.value.data ?? notifRes.value) : null;
      const referralData = referralRes.status === 'fulfilled' ? (referralRes.value.data ?? referralRes.value) : null;
      const savedData = savedRes.status === 'fulfilled' ? (savedRes.value.data ?? savedRes.value) : null;

      setApps((appsData?.applications ?? []).slice(0, 5));
      setStats({
        stats: statsData?.stats ?? [],
        total: statsData?.total ?? 0,
      });
      setCompanies(companiesData);
      setCompanyCount(compRes.status === 'fulfilled' ? (compRes.value?.pagination?.total ?? compRes.value?.total ?? companiesData.length) : companiesData.length);
      setFeed(feedData?.experiences ?? []);
      setNotifications(Array.isArray(notifData?.data) ? notifData.data : (Array.isArray(notifData?.notifications) ? notifData.notifications : []));
      setReferrals(Array.isArray(referralData?.data) ? referralData.data : (Array.isArray(referralData?.referrals) ? referralData.referrals : []));
      setSavedCompanies(Array.isArray(savedData?.companies) ? savedData.companies : []);
    }).catch(() => toast.error('Failed to load dashboard'))
      .finally(() => setLoading(false));
  }, []);

  const statMap = Object.fromEntries((stats.stats || []).map(s => [s._id, s.count]));
  const appliedCompanyIds = useMemo(() => new Set((apps || []).map((app) => String(app.company?._id || app.company))), [apps]);

  const savedCompanyIds = useMemo(() => {
    const ids = new Set((user?.savedCompanies || []).map(String));
    savedCompanies.forEach((company) => ids.add(String(company._id)));
    return ids;
  }, [savedCompanies, user?.savedCompanies]);

  const recommendedCompanies = useMemo(() => {
    const branch = user?.branch;
    const batch = user?.batch;
    return companies
      .filter((company) => !appliedCompanyIds.has(String(company._id)))
      .filter((company) => !savedCompanyIds.has(String(company._id)))
      .filter((company) => {
        const eligibleBranch = !branch || !Array.isArray(company.eligibility?.branches) || !company.eligibility.branches.length || company.eligibility.branches.includes(branch);
        const eligibleBatch = !batch || true;
        return eligibleBranch && eligibleBatch;
      })
      .slice(0, 3);
  }, [companies, appliedCompanyIds, savedCompanyIds, user?.branch, user?.batch]);

  const urgentAlerts = useMemo(() => {
    const now = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    const alerts = [];

    apps.forEach((app) => {
      const slotDate = app.interviewSlot?.date ? new Date(app.interviewSlot.date).getTime() : null;
      if (slotDate && slotDate - now <= dayMs && slotDate >= now) {
        alerts.push({
          key: `slot-${app._id}`,
          title: `${app.company?.name || 'Interview'} in the next 24 hours`,
          description: app.interviewSlot?.venue || app.interviewSlot?.time || 'Interview slot assigned',
          to: '/student/applications',
          tone: 'warning',
        });
      }
    });

    companies.forEach((company) => {
      if (company.applicationDeadline) {
        const deadline = new Date(company.applicationDeadline).getTime();
        if (deadline >= now && deadline - now <= dayMs && !appliedCompanyIds.has(String(company._id))) {
          alerts.push({
            key: `deadline-${company._id}`,
            title: `${company.name} deadline in 24 hours`,
            description: 'Apply before the cutoff',
            to: `/companies/${company._id}`,
            tone: 'danger',
          });
        }
      }
    });

    notifications.slice(0, 6).forEach((notif) => {
      if (['shortlist', 'status_update', 'interview_slot', 'offer'].includes(notif.type) && !notif.isRead) {
        alerts.push({
          key: `notif-${notif._id}`,
          title: notif.title,
          description: notif.message,
          to: '/student/notifications',
          tone: 'accent',
        });
      }
    });

    return alerts.slice(0, 5);
  }, [apps, companies, notifications, appliedCompanyIds]);

  const activityFeed = useMemo(() => {
    const items = [
      ...apps.slice(0, 3).map((app) => ({
        key: `app-${app._id}`,
        label: `${app.company?.name || 'Company'} · ${app.status.replace(/_/g, ' ')}`,
        detail: app.statusHistory?.[0]?.note || 'Application activity',
        time: app.updatedAt || app.createdAt,
        to: '/student/applications',
      })),
      ...notifications.slice(0, 3).map((notif) => ({
        key: `notif-${notif._id}`,
        label: notif.title,
        detail: notif.message,
        time: notif.createdAt,
        to: '/student/notifications',
      })),
      ...referrals.slice(0, 3).map((referral) => ({
        key: `ref-${referral._id}`,
        label: `${referral.company} · ${referral.role}`,
        detail: referral.lifecycleStatus?.replace('_', ' ') || referral.type,
        time: referral.createdAt,
        to: '/student/referrals',
      })),
    ];

    return items.sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 6);
  }, [apps, notifications, referrals]);

  if (loading) return <DashboardSkeleton />;

  const quickStats = [
    { icon: FileText,   label: 'Applications',    value: stats.total,              iconBg: 'var(--role-cyan-tint)', iconColor: 'var(--role-cyan)', hoverBorder: 'var(--role-cyan)', to: '/student/applications' },
    { icon: TrendingUp, label: 'Shortlisted',     value: statMap.shortlisted || 0, iconBg: 'var(--role-magenta-tint)', iconColor: 'var(--role-magenta)', hoverBorder: 'var(--role-magenta)', to: '/student/applications' },
    { icon: Zap,        label: 'Active Companies', value: companyCount,             iconBg: 'var(--role-gold-tint)', iconColor: 'var(--role-gold)', hoverBorder: 'var(--role-gold)', to: '/student/companies' },
    { icon: BookOpen,   label: 'Experiences',     value: feed.length,               iconBg: 'var(--role-coral-tint)', iconColor: 'var(--role-coral)', hoverBorder: 'var(--role-coral)', to: '/student/experiences' },
  ];

  const quickActions = [
    { label: 'Browse Companies',      icon: Building2,    to: '/student/companies',   iconBg: 'var(--role-cyan-tint)', iconColor: 'var(--role-cyan)' },
    { label: 'Interview Experiences', icon: BookOpen,     to: '/student/experiences', iconBg: 'var(--role-magenta-tint)', iconColor: 'var(--role-magenta)' },
    { label: 'AI Interview Prep',     icon: BrainCircuit, to: '/student/ai-prep',     iconBg: 'var(--role-cyan-tint)', iconColor: 'var(--role-cyan)' },
    { label: 'Alumni Referrals',      icon: Award,        to: '/student/referrals',   iconBg: 'var(--role-coral-tint)', iconColor: 'var(--role-coral)' },
    { label: 'Compare Offers',        icon: TrendingUp,   to: '/student/offers',      iconBg: 'var(--role-gold-tint)', iconColor: 'var(--role-gold)' },
    { label: 'Salary Insights',       icon: DollarSign,   to: '/student/salary',      iconBg: 'var(--role-gold-tint)', iconColor: 'var(--role-gold)' },
    { label: 'Notifications',         icon: Bell,         to: '/student/notifications', iconBg: 'var(--role-cyan-tint)', iconColor: 'var(--role-cyan)' },
  ];

  return (
    <div className="page-enter" style={{ padding: 'clamp(16px,4vw,24px)', display: 'flex', flexDirection: 'column', gap: 20 }}>

      {/* ── Welcome banner ─────────────────────────────────────────── */}
      <div
        className="hero-shell hero-shell--student"
        style={{
          borderRadius: 'var(--radius-card)',
          padding:      '20px 24px',
          display:      'flex',
          alignItems:   'center',
          justifyContent: 'space-between',
          gap:          16,
          // Subtle left accent strip
          borderLeft:   '3px solid var(--role-cyan)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <Avatar name={user?.name} size="lg" src={user?.profilePic} />
          <div>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 2 }}>{greeting()},</p>
            <h1 style={{ fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.015em' }}>
              {user?.name?.split(' ')[0]} 👋
            </h1>
            {user?.branch && (
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
                {user.branch} · Batch {user.batch}
              </p>
            )}
          </div>
        </div>

        {/* AI Prep CTA */}
        <Link
          to="/student/ai-prep"
          style={{
            display:        'inline-flex',
            alignItems:     'center',
            gap:            8,
            padding:        '10px 18px',
            background:     'var(--accent)',
            color:          '#fff',
            fontWeight:     700,
            fontSize:       13,
            borderRadius:   'var(--radius-input)',
            textDecoration: 'none',
            flexShrink:     0,
            boxShadow:      'var(--btn-shadow-cyan)',
            transition:     'background 0.18s ease, transform 0.18s ease',
          }}
          onMouseEnter={e => { e.currentTarget.style.background = 'var(--accent-hover)'; e.currentTarget.style.transform = 'translateY(-1px)'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'var(--accent)';        e.currentTarget.style.transform = 'translateY(0)';    }}
          className="hidden sm:inline-flex"
        >
          <BrainCircuit size={14} /> AI Prep
        </Link>
      </div>

      {/* ── Quick stats ────────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 14 }}>
        {quickStats.map(s => <QuickStat key={s.label} {...s} />)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 14 }}>
        {recommendedCompanies.length > 0 && (
          <Panel title="Recommended Companies" action={<Link to="/student/companies" style={{ color: 'var(--accent)', fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>Explore</Link>}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {recommendedCompanies.map((company) => (
                <Link key={company._id} to={`/companies/${company._id}`} style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
                  <CompanyLogo logo={company.logo} name={company.name} size="sm" />
                  <div style={{ minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>{company.name}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0 }}>{company.sector}</p>
                  </div>
                </Link>
              ))}
            </div>
          </Panel>
        )}

        <Panel title="Urgent Alerts" action={<Link to="/student/notifications" style={{ color: 'var(--accent)', fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>Open notifications</Link>}>
          {urgentAlerts.length === 0 ? (
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>No urgent alerts right now.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {urgentAlerts.map((alert) => (
                <Link key={alert.key} to={alert.to} style={{ display: 'block', textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-input)', padding: '10px 12px', background: alert.tone === 'danger' ? 'var(--role-coral-tint)' : 'var(--surface-2)' }}>
                    <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>{alert.title}</p>
                    <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '4px 0 0' }}>{alert.description}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="Saved Companies" action={<Link to="/student/companies" style={{ color: 'var(--accent)', fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>Manage</Link>}>
          {savedCompanies.length === 0 ? (
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Save companies you want to revisit later.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {savedCompanies.slice(0, 4).map((company) => (
                <Link key={company._id} to={`/companies/${company._id}`} style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
                  <CompanyLogo logo={company.logo} name={company.name} size="sm" />
                  <div style={{ minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>{company.name}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-muted)', margin: 0 }}>{company.applicationDeadline ? `Deadline ${new Date(company.applicationDeadline).toLocaleDateString('en-IN')}` : 'No deadline set'}</p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </Panel>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.2fr) minmax(0,0.8fr)', gap: 20 }} className="lg:grid-cols-[1.2fr_0.8fr] grid-cols-1">
        <Panel title="Activity Feed" action={<Link to="/student/notifications" style={{ color: 'var(--accent)', fontSize: 12, fontWeight: 600, textDecoration: 'none' }}>All activity</Link>}>
          {activityFeed.length === 0 ? (
            <p style={{ fontSize: 13, color: 'var(--text-muted)' }}>Your recent activity will appear here.</p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {activityFeed.map((item) => (
                <Link key={item.key} to={item.to} style={{ textDecoration: 'none', color: 'inherit' }}>
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                    <div style={{ width: 30, height: 30, borderRadius: 10, background: 'var(--role-cyan-tint)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <ClipboardList size={14} style={{ color: 'var(--accent)' }} />
                    </div>
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>{item.label}</p>
                      <p style={{ margin: '3px 0 0', fontSize: 12, color: 'var(--text-muted)' }}>{item.detail}</p>
                      <p style={{ margin: '4px 0 0', fontSize: 11, color: 'var(--text-muted)' }}>
                        {item.time ? formatDistanceToNow(new Date(item.time), { addSuffix: true }) : 'Just now'}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </Panel>

        <Panel title="Resume Your Work">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Link to="/student/ai-prep" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--role-cyan-tint)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <BrainCircuit size={14} style={{ color: 'var(--accent)' }} />
              </div>
              <div>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>Continue AI prep</p>
                <p style={{ margin: 0, fontSize: 12, color: 'var(--text-muted)' }}>Pick up your next mock interview</p>
              </div>
            </Link>
            <Link to="/student/referrals" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--role-coral-tint)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Award size={14} style={{ color: 'var(--role-coral)' }} />
              </div>
              <div>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>Review referrals</p>
                <p style={{ margin: 0, fontSize: 12, color: 'var(--text-muted)' }}>{referrals.length} recent referral{referrals.length === 1 ? '' : 's'}</p>
              </div>
            </Link>
            <Link to="/student/offers" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', color: 'inherit' }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: 'var(--role-gold-tint)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <TrendingUp size={14} style={{ color: 'var(--warning)' }} />
              </div>
              <div>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: 'var(--text-primary)' }}>Compare offers</p>
                <p style={{ margin: 0, fontSize: 12, color: 'var(--text-muted)' }}>Keep your offer decisions moving</p>
              </div>
            </Link>
          </div>
        </Panel>
      </div>

      {/* ── Main content grid ──────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: 20, alignItems: 'start' }}
        className="lg:grid-cols-[2fr_1fr] grid-cols-1">

        {/* Left column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

          {/* My Applications */}
          <div>
            <SectionHeader title="My Applications" to="/student/applications" />
            {apps.length === 0 ? (
              <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', padding: '36px 24px', textAlign: 'center', boxShadow: 'var(--shadow-soft)' }}>
                <FileText size={28} style={{ color: 'var(--text-muted)', margin: '0 auto 12px' }} />
                <p style={{ fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 4 }}>No applications yet</p>
                <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 18 }}>Browse companies and start applying</p>
                <Link
                  to="/student/companies"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '9px 18px', background: 'var(--accent)', color: '#fff', fontWeight: 700, fontSize: 13, borderRadius: 'var(--radius-input)', textDecoration: 'none' }}
                >
                  Browse Companies <ArrowRight size={13} />
                </Link>
              </div>
            ) : (
              <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', overflow: 'hidden', boxShadow: 'var(--shadow-soft)' }}>
                {apps.map((app, idx) => (
                  <div
                    key={app._id}
                    onClick={() => navigate('/student/applications')}
                    style={{
                      display:       'flex',
                      alignItems:    'center',
                      gap:           12,
                      padding:       '12px 16px',
                      borderBottom:  idx < apps.length - 1 ? '1px solid var(--border)' : 'none',
                      cursor:        'pointer',
                      transition:    'background 0.15s ease',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <CompanyLogo logo={app.company?.logo} name={app.company?.name} size="sm" />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {app.company?.name}
                      </p>
                      <p style={{ fontSize: 12, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        {app.company?.roles?.slice(0, 2).join(', ') || app.company?.sector}
                      </p>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 3, flexShrink: 0 }}>
                      <StatusBadge status={app.status} />
                      <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>
                        {formatDistanceToNow(new Date(app.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* New Companies */}
          <div>
            <SectionHeader title="New Companies" to="/student/companies" />
            {companies.length === 0 ? (
              <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', padding: '24px', textAlign: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
                No companies added yet by your coordinator.
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 12 }}>
                {companies.map(c => (
                  <Link
                    key={c._id}
                    to={`/companies/${c._id}`}
                    style={{
                      display:        'flex',
                      alignItems:     'center',
                      gap:            12,
                      padding:        '14px 16px',
                      background:     'var(--surface)',
                      border:         '1px solid var(--border)',
                      borderRadius:   'var(--radius-card)',
                      textDecoration: 'none',
                      boxShadow:      'var(--shadow-soft)',
                      transition:     'transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease',
                    }}
                    onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = 'var(--shadow-hover)'; e.currentTarget.style.borderColor = 'rgba(10,132,255,0.3)'; }}
                    onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)';    e.currentTarget.style.boxShadow = 'var(--shadow-soft)'; e.currentTarget.style.borderColor = 'var(--border)'; }}
                  >
                    <CompanyLogo logo={c.logo} name={c.name} size="sm" />
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</p>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}>
                        <span style={{ fontSize: 11, color: 'var(--text-muted)' }}>{c.sector}</span>
                        {c.applicationDeadline && <Countdown deadline={c.applicationDeadline} />}
                      </div>
                    </div>
                    <ArrowRight size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

          {/* Quick actions */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', padding: '18px 16px', boxShadow: 'var(--shadow-soft)' }}>
            <h2 style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 12 }}>Quick Actions</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {quickActions.map(({ label, icon: Icon, to, iconBg, iconColor }) => (
                <Link
                  key={to}
                  to={to}
                  style={{
                    display:        'flex',
                    alignItems:     'center',
                    gap:            10,
                    padding:        '9px 10px',
                    borderRadius:   10,
                    textDecoration: 'none',
                    transition:     'background 0.15s ease',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <span style={{ width: 28, height: 28, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: iconBg }}>
                    <Icon size={13} style={{ color: iconColor }} />
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-secondary)', flex: 1 }}>{label}</span>
                  <ArrowRight size={12} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
                </Link>
              ))}
            </div>
          </div>

          {/* Recent experiences */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', overflow: 'hidden', boxShadow: 'var(--shadow-soft)' }}>
            {/* Header */}
            <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <h2 style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>Recent Experiences</h2>
              <Link to="/student/experiences" style={{ fontSize: 12, fontWeight: 600, color: 'var(--accent)', textDecoration: 'none' }}>
                See all
              </Link>
            </div>

            {feed.length === 0 ? (
              <div style={{ padding: '24px 16px', textAlign: 'center', fontSize: 13, color: 'var(--text-muted)' }}>
                No experiences posted yet
              </div>
            ) : feed.map((exp, idx) => {
              const vs = verdictStyle[exp.verdict] || verdictStyle.waitlisted;
              return (
                <Link
                  key={exp._id}
                  to={`/experiences/${exp._id}`}
                  style={{
                    display:        'flex',
                    alignItems:     'flex-start',
                    gap:            10,
                    padding:        '11px 16px',
                    borderBottom:   idx < feed.length - 1 ? '1px solid var(--border)' : 'none',
                    textDecoration: 'none',
                    transition:     'background 0.15s ease',
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <CompanyLogo logo={exp.company?.logo} name={exp.company?.name} size="sm" />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {exp.company?.name}
                    </p>
                    <p style={{ fontSize: 11, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{exp.role}</p>
                    <span style={{ display: 'inline-flex', marginTop: 4, fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 'var(--radius-pill)', background: vs.background, color: vs.color, textTransform: 'capitalize' }}>
                      {exp.verdict}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
