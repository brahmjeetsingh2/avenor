import React, { useEffect, useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import mentorshipService from '../../services/mentorshipService';
import Button from '../../components/ui/Button';

const STATUS_OPTIONS = [
  { value: '', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'accepted', label: 'Accepted' },
  { value: 'declined', label: 'Declined' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
];

const StudentMentorshipRequestsPage = () => {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('');
  const [updateText, setUpdateText] = useState({});

  const fetchRows = async () => {
    setLoading(true);
    try {
      const res = await mentorshipService.getMine({ status: statusFilter || undefined, limit: 100 });
      setRows(res.data || []);
    } catch {
      toast.error('Failed to load mentorship requests');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRows();
  }, [statusFilter]);

  const cancel = async (id) => {
    try {
      await mentorshipService.cancel(id);
      toast.success('Request cancelled');
      fetchRows();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not cancel request');
    }
  };

  const addUpdate = async (row) => {
    const message = (updateText[row._id] || '').trim();
    if (!message) return;

    try {
      await mentorshipService.addUpdate(row._id, { message });
      setUpdateText((p) => ({ ...p, [row._id]: '' }));
      toast.success('Session update posted');
      fetchRows();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Could not add update');
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6 page-enter space-y-5">
      <div className="card p-5 border-[rgba(90,169,230,0.22)]" style={{ background: 'linear-gradient(90deg, var(--role-cyan-tint), var(--role-coral-tint))' }}>
        <h1 className="font-display text-2xl font-bold text-[var(--color-text-primary)]">My Mentorship Requests</h1>
        <p className="text-sm text-[var(--color-text-muted)] mt-1">Track the status of mentorship requests sent to alumni.</p>
        <div className="mt-3">
          <select className="input max-w-48" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {loading ? (
        <div className="card p-8 text-sm">Loading mentorship requests...</div>
      ) : rows.length === 0 ? (
        <div className="card p-12 text-center">
          <MessageSquare size={24} className="mx-auto text-[var(--color-text-muted)] mb-3" />
          <p className="font-semibold">No mentorship requests yet</p>
          <p className="text-sm text-[var(--color-text-muted)] mt-1">Request mentorship from alumni on referrals or their profile context.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {rows.map((r) => (
            <div key={r._id} className="card p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{r.alumni?.name || 'Alumni'} · {r.topic.replace('_', ' ')}</p>
                  <p className="text-xs text-[var(--color-text-muted)] mt-1">{r.alumni?.college || ''} · {new Date(r.createdAt).toLocaleDateString('en-IN')}</p>
                </div>
                <span className="text-xs font-semibold px-2 py-1 rounded-lg bg-[var(--role-cyan-tint)] border border-[rgba(90,169,230,0.22)] text-[var(--role-cyan)]">{r.status}</span>
              </div>

              <p className="text-sm text-[var(--color-text-secondary)]">{r.message}</p>
              {r.responseNote ? <p className="text-xs text-[var(--color-text-muted)]">Response note: {r.responseNote}</p> : null}

              {r.status === 'accepted' && r.session?.isActive && (
                <div className="rounded-xl border border-[rgba(255, 99, 146, 0.22)] bg-[var(--role-coral-tint)] p-3 text-sm text-[var(--role-coral)]">
                  Mentorship Session Activated with {r.alumni?.name || 'alumni'} · Progress {r.sessionProgress?.completed || 0}/{r.sessionProgress?.total || 0}
                </div>
              )}

              {r.session?.milestones?.length ? (
                <div className="space-y-2">
                  {r.session.milestones.map((m) => (
                    <div key={m._id} className={`rounded-xl border p-3 text-sm ${m.status === 'completed' ? 'border-[rgba(255, 99, 146, 0.22)] bg-[var(--role-coral-tint)]' : 'border-[var(--color-border)]'}`}>
                      <span className="font-semibold">{m.title}</span>
                      <span className="ml-2 text-xs text-[var(--color-text-muted)]">{m.status}</span>
                    </div>
                  ))}
                </div>
              ) : null}

              {r.session?.updates?.length ? (
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-[var(--color-text-muted)] uppercase">Session Updates</p>
                  <div className="space-y-1">
                    {r.session.updates.slice(-4).map((u, idx) => (
                      <div key={`${u.createdAt || idx}-${idx}`} className="text-xs text-[var(--color-text-muted)] rounded-lg bg-[var(--color-surface)] border border-[var(--color-border)] px-2 py-1.5">
                        <span className="font-semibold capitalize">{u.actorRole}</span>: {u.message}
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              {r.session?.isActive && (
                <div className="flex gap-2">
                  <input
                    className="input"
                    placeholder="Add session update"
                    value={updateText[r._id] || ''}
                    onChange={(e) => setUpdateText((p) => ({ ...p, [r._id]: e.target.value }))}
                  />
                  <Button size="sm" onClick={() => addUpdate(r)}>Add</Button>
                </div>
              )}

              {['pending', 'accepted'].includes(r.status) && (
                <div className="pt-2 border-t border-[var(--color-border)]">
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="secondary" leftIcon={<X size={13} />} onClick={() => cancel(r._id)}>Cancel Request</Button>
                    <Link to={`/mentorship/${r._id}`} className="text-xs font-semibold text-[var(--role-cyan)] hover:text-[var(--role-cyan-deep)]">Open Session</Link>
                  </div>
                </div>
              )}

              {!['pending', 'accepted'].includes(r.status) && (
                <div className="pt-2 border-t border-[var(--color-border)]">
                  <Link to={`/mentorship/${r._id}`} className="text-xs font-semibold text-[var(--role-cyan)] hover:text-[var(--role-cyan-deep)]">Open Session</Link>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default StudentMentorshipRequestsPage;
