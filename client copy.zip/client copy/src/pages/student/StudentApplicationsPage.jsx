import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { LayoutGrid, List, Briefcase, ArrowRight, Download, Search, Filter } from 'lucide-react';
import toast from 'react-hot-toast';
import applicationService from '../../services/applicationService';
import { StatusBadge, STATUS_CONFIG, KANBAN_COLUMNS } from '../../utils/applicationStatus';
import ApplicationDetailModal from '../../components/shared/ApplicationDetailModal';
import { CompanyLogo } from '../../components/shared/CompanyCard';
import { CompanyCardSkeleton } from '../../components/shared/Skeleton';

// ─── Funnel stats bar ─────────────────────────────────────────────────────────
const FUNNEL_ITEMS = [
  { label: 'Applied',     key: 'applied',      barColor: 'var(--accent)'  },
  { label: 'Shortlisted', key: 'shortlisted',  barColor: 'var(--accent)'  },
  { label: 'Interviews',  key: 'interview_r1', barColor: 'var(--warning)' },
  { label: 'Offers',      key: 'offer',        barColor: 'var(--status-success)' },
  { label: 'Rejected',    key: 'rejected',     barColor: 'var(--danger)'  },
];

const FunnelStats = ({ stats, total }) => {
  const map = Object.fromEntries((stats || []).map((s) => [s._id, s.count]));

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))', gap: 12, marginBottom: 20 }}>
      {FUNNEL_ITEMS.map(({ label, key, barColor }) => {
        const count = map[key] || 0;
        const pct   = Math.min(100, (count / (total || 1)) * 100);
        const cfg   = STATUS_CONFIG[key];
        return (
          <div
            key={key}
            style={{
              background:   'var(--surface)',
              border:       '1px solid var(--border)',
              borderRadius: 'var(--radius-card)',
              padding:      '16px 14px',
              textAlign:    'center',
              boxShadow:    'var(--shadow-soft)',
            }}
          >
            <div style={{ fontSize: 26, fontWeight: 700, color: cfg?.color || 'var(--accent)', letterSpacing: '-0.02em', lineHeight: 1 }}>
              {count}
            </div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4, marginBottom: 10 }}>{label}</div>
            <div style={{ height: 3, borderRadius: 999, background: 'var(--border)', overflow: 'hidden' }}>
              <div style={{ height: '100%', borderRadius: 999, background: barColor, width: `${pct}%`, minWidth: count ? 4 : 0, transition: 'width 0.6s ease' }} />
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ─── Kanban card ──────────────────────────────────────────────────────────────
const KanbanCard = ({ application, onClick }) => {
  const { company, createdAt } = application;
  return (
    <div
      onClick={() => onClick(application)}
      style={{
        background:   'var(--surface)',
        border:       '1px solid var(--border)',
        borderRadius: 'var(--radius-card)',
        padding:      '14px',
        cursor:       'pointer',
        transition:   'transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform   = 'translateY(-2px)';
        e.currentTarget.style.boxShadow   = 'var(--shadow-hover)';
        e.currentTarget.style.borderColor = 'rgba(10,132,255,0.3)';
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform   = 'translateY(0)';
        e.currentTarget.style.boxShadow   = 'none';
        e.currentTarget.style.borderColor = 'var(--border)';
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
        <CompanyLogo logo={company?.logo} name={company?.name} size="sm" />
        <div style={{ minWidth: 0 }}>
          <p style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {company?.name}
          </p>
          <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{company?.sector}</p>
        </div>
      </div>

      {company?.ctc?.max > 0 && (
        <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6 }}>
          ₹{company.ctc.min}–{company.ctc.max} LPA
        </p>
      )}
      {company?.roles?.length > 0 && (
        <p style={{ fontSize: 11, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 6 }}>
          {company.roles.slice(0, 2).join(', ')}
        </p>
      )}
      <p style={{ fontSize: 10, color: 'var(--text-muted)' }}>
        Applied {new Date(createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
      </p>
    </div>
  );
};

// ─── Table row ────────────────────────────────────────────────────────────────
const TableRow = ({ application, onClick }) => {
  const { company, status, createdAt, interviewSlot } = application;
  return (
    <tr
      onClick={() => onClick(application)}
      style={{ cursor: 'pointer', transition: 'background 0.15s ease', borderBottom: '1px solid var(--border)' }}
      onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      <td style={{ padding: '12px 16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <CompanyLogo logo={company?.logo} name={company?.name} size="sm" />
          <div>
            <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{company?.name}</p>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{company?.sector}</p>
          </div>
        </div>
      </td>
      <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)' }}>
        {company?.roles?.slice(0, 2).join(', ') || '—'}
      </td>
      <td style={{ padding: '12px 16px' }}>
        <StatusBadge status={status} />
      </td>
      <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)' }}>
        {interviewSlot?.date
          ? new Date(interviewSlot.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
          : '—'}
      </td>
      <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-muted)' }}>
        {new Date(createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit' })}
      </td>
      <td style={{ padding: '12px 16px' }}>
        <ArrowRight size={14} style={{ color: 'var(--text-muted)' }} />
      </td>
    </tr>
  );
};

// ─── Main page ────────────────────────────────────────────────────────────────
const StudentApplicationsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [applications, setApplications] = useState([]);
  const [stats,        setStats]        = useState({ stats: [], total: 0 });
  const [loading,      setLoading]      = useState(true);
  const [view,         setView]         = useState('kanban');
  const [selected,     setSelected]     = useState(null);
  const [modalOpen,    setModalOpen]    = useState(false);
  const handledApplyState = useRef(false);
  const handledFocusState = useRef(false);
  const [filters, setFilters] = useState({ search: '', status: '', company: '', recency: 'all' });

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [appsRes, statsRes] = await Promise.all([
        applicationService.getMyApps(),
        applicationService.getMyStats(),
      ]);

      // Backend wraps responses as { success, data: { applications } }
      // axios response is: res.data = { success, data: { applications } }
      const appsData  = appsRes.data?.data ?? appsRes.data;
      const statsData = statsRes.data?.data ?? statsRes.data;

      setApplications(appsData?.applications ?? []);
      setStats({
        stats: statsData?.stats ?? [],
        total: statsData?.total ?? 0,
      });
    } catch {
      toast.error('Failed to load applications');
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (handledFocusState.current) return;
    const focusApplicationId = location.state?.focusApplicationId;
    if (!focusApplicationId || applications.length === 0) return;

    const match = applications.find((app) => app._id === focusApplicationId);
    if (!match) return;

    handledFocusState.current = true;
    openDetail(match);
    navigate(location.pathname, { replace: true, state: null });
  }, [applications, location.pathname, location.state, navigate]);

  // Show apply-result toast when we arrive from the company detail page
  useEffect(() => {
    if (handledApplyState.current) return;

    const applyToast = location.state?.applyToast;
    const applyToastType = location.state?.applyToastType;
    if (!applyToast) return;

    handledApplyState.current = true;
    const showToast = applyToastType === 'error' ? toast.error : toast.success;
    showToast(applyToast, { id: 'application-flow-toast' });
    navigate(location.pathname, { replace: true, state: null });
  }, [location.pathname, location.state, navigate]);

  const handleWithdraw = async (id) => {
    try {
      await applicationService.withdraw(id);
      toast.success('Application withdrawn');
      setModalOpen(false);
      fetchData();
    } catch {
      toast.error('Failed to withdraw');
    }
  };

  const openDetail = (app) => { setSelected(app); setModalOpen(true); };

  const filteredApplications = useMemo(() => {
    const now = Date.now();
    const weekMs = 7 * 24 * 60 * 60 * 1000;

    return applications.filter((app) => {
      const searchText = `${app.company?.name || ''} ${app.company?.sector || ''} ${(app.company?.roles || []).join(' ')} ${app.company?.location || ''}`.toLowerCase();
      const searchMatch = !filters.search || searchText.includes(filters.search.toLowerCase());
      const statusMatch = !filters.status || app.status === filters.status;
      const companyMatch = !filters.company || String(app.company?._id || '') === filters.company;

      let recencyMatch = true;
      if (filters.recency === '7d') {
        recencyMatch = new Date(app.createdAt).getTime() >= now - weekMs;
      } else if (filters.recency === '30d') {
        recencyMatch = new Date(app.createdAt).getTime() >= now - (30 * weekMs / 7);
      } else if (filters.recency === '90d') {
        recencyMatch = new Date(app.createdAt).getTime() >= now - (90 * weekMs / 7);
      }

      return searchMatch && statusMatch && companyMatch && recencyMatch;
    });
  }, [applications, filters]);

  const companyOptions = useMemo(() => {
    const seen = new Map();
    applications.forEach((app) => {
      if (app.company?._id && app.company?.name) seen.set(String(app.company._id), app.company.name);
    });
    return [...seen.entries()].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name));
  }, [applications]);

  const exportCsv = () => {
    if (!filteredApplications.length) {
      toast.error('No applications to export');
      return;
    }

    const rows = [
      ['Company', 'Role', 'Status', 'Applied Date', 'Interview Slot'],
      ...filteredApplications.map((app) => [
        app.company?.name || '',
        (app.company?.roles || []).slice(0, 2).join(' / '),
        app.status,
        new Date(app.createdAt).toLocaleDateString('en-IN'),
        app.interviewSlot?.date ? new Date(app.interviewSlot.date).toLocaleDateString('en-IN') : '',
      ]),
    ];

    const csv = rows.map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `applications-${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Group by status for kanban
  const grouped = KANBAN_COLUMNS.reduce((acc, col) => {
    acc[col.id] = filteredApplications.filter((a) => a.status === col.id);
    return acc;
  }, {});

  const hasAny = filteredApplications.length > 0;

  return (
    <div className="page-enter" style={{ padding: 'clamp(16px,4vw,24px)' }}>

      {/* ── Header ─────────────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 'clamp(20px,3vw,26px)', fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.02em' }}>
            My Applications
          </h1>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 3 }}>{filteredApplications.length} visible of {stats.total} total applications</p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
          <button
            onClick={exportCsv}
            style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '8px 12px', borderRadius: 10, border: '1px solid var(--border)', background: 'var(--surface)', color: 'var(--text-secondary)', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}
          >
            <Download size={14} /> Export
          </button>

          {/* View toggle */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 2, padding: 4, borderRadius: 10, background: 'var(--surface-2)', border: '1px solid var(--border)' }}>
            {[{ id: 'kanban', icon: LayoutGrid }, { id: 'table', icon: List }].map(({ id, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setView(id)}
                style={{
                  padding:      '6px 8px',
                  borderRadius: 7,
                  border:       'none',
                  cursor:       'pointer',
                  background:   view === id ? 'var(--surface)' : 'transparent',
                  color:        view === id ? 'var(--accent)' : 'var(--text-muted)',
                  boxShadow:    view === id ? 'var(--shadow-soft)' : 'none',
                  transition:   'all 0.15s ease',
                }}
              >
                <Icon size={15} />
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 12, marginBottom: 14 }}>
        <div style={{ position: 'relative' }}>
          <Search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input
            className="input"
            style={{ paddingLeft: 34 }}
            placeholder="Search company or role"
            value={filters.search}
            onChange={(e) => setFilters((prev) => ({ ...prev, search: e.target.value }))}
          />
        </div>
        <select className="input" value={filters.status} onChange={(e) => setFilters((prev) => ({ ...prev, status: e.target.value }))}>
          <option value="">All statuses</option>
          {Object.keys(KANBAN_COLUMNS.reduce((acc, item) => ({ ...acc, [item.id]: true }), {})).map((status) => (
            <option key={status} value={status}>{status.replace(/_/g, ' ')}</option>
          ))}
        </select>
        <select className="input" value={filters.company} onChange={(e) => setFilters((prev) => ({ ...prev, company: e.target.value }))}>
          <option value="">All companies</option>
          {companyOptions.map((company) => (
            <option key={company.id} value={company.id}>{company.name}</option>
          ))}
        </select>
        <select className="input" value={filters.recency} onChange={(e) => setFilters((prev) => ({ ...prev, recency: e.target.value }))}>
          <option value="all">Any time</option>
          <option value="7d">Last 7 days</option>
          <option value="30d">Last 30 days</option>
          <option value="90d">Last 90 days</option>
        </select>
      </div>

      {/* ── Funnel stats ───────────────────────────────────────────── */}
      {!loading && hasAny && <FunnelStats stats={stats.stats} total={stats.total} />}

      {/* ── Loading ────────────────────────────────────────────────── */}
      {loading && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(260px,1fr))', gap: 16 }}>
          {Array.from({ length: 6 }).map((_, i) => <CompanyCardSkeleton key={i} />)}
        </div>
      )}

      {/* ── Empty state ────────────────────────────────────────────── */}
      {!loading && !hasAny && (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '80px 24px', textAlign: 'center' }}>
          <div style={{ width: 64, height: 64, borderRadius: 18, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
            <Briefcase size={28} style={{ color: 'var(--text-muted)' }} />
          </div>
          <h3 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>No applications yet</h3>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>Browse companies and hit Apply to get started.</p>
          <button
            onClick={() => navigate('/student/companies')}
            style={{
              display:      'inline-flex',
              alignItems:   'center',
              gap:          8,
              padding:      '11px 22px',
              background:   'var(--accent)',
              color:        '#fff',
              fontWeight:   700,
              fontSize:     14,
              borderRadius: 'var(--radius-input)',
              border:       'none',
              cursor:       'pointer',
              transition:   'background 0.18s ease',
            }}
            onMouseEnter={e => e.currentTarget.style.background = 'var(--accent-hover)'}
            onMouseLeave={e => e.currentTarget.style.background = 'var(--accent)'}
          >
            Browse Companies <ArrowRight size={15} />
          </button>
        </div>
      )}

      {/* ── Kanban view ────────────────────────────────────────────── */}
      {!loading && hasAny && view === 'kanban' && (
        <div style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingBottom: 16, marginLeft: -4, paddingLeft: 4 }}>
          {KANBAN_COLUMNS
            .filter((col) => grouped[col.id]?.length > 0 || ['applied', 'shortlisted', 'offer'].includes(col.id))
            .map((col) => {
              const cfg   = STATUS_CONFIG[col.id];
              const items = grouped[col.id] || [];
              return (
                <div key={col.id} style={{ flexShrink: 0, width: 252, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {/* Column header */}
                  <div
                    style={{
                      display:        'flex',
                      alignItems:     'center',
                      justifyContent: 'space-between',
                      padding:        '8px 12px',
                      borderRadius:   'var(--radius-input)',
                      background:     cfg.bg,
                      border:         `1px solid ${cfg.border}`,
                    }}
                  >
                    <span style={{ fontSize: 12, fontWeight: 700, color: cfg.color }}>{col.label}</span>
                    <span
                      style={{
                        fontSize: 11, fontWeight: 700,
                        width: 20, height: 20, borderRadius: '50%',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        background: cfg.bg, color: cfg.color,
                      }}
                    >
                      {items.length}
                    </span>
                  </div>

                  {/* Cards */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, minHeight: 60 }}>
                    {items.map((app) => <KanbanCard key={app._id} application={app} onClick={openDetail} />)}
                    {items.length === 0 && (
                      <div
                        style={{
                          height:         64,
                          borderRadius:   'var(--radius-card)',
                          border:         '1.5px dashed var(--border)',
                          display:        'flex',
                          alignItems:     'center',
                          justifyContent: 'center',
                        }}
                      >
                        <p style={{ fontSize: 12, color: 'var(--text-muted)' }}>None</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      )}

      {/* ── Table view ─────────────────────────────────────────────── */}
      {!loading && hasAny && view === 'table' && (
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-card)', overflow: 'hidden', boxShadow: 'var(--shadow-soft)' }}>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)' }}>
                  {['Company', 'Role', 'Status', 'Interview', 'Applied', ''].map((h) => (
                    <th
                      key={h}
                      style={{
                        padding:       '10px 16px',
                        textAlign:     'left',
                        fontSize:      11,
                        fontWeight:    700,
                        color:         'var(--text-muted)',
                        textTransform: 'uppercase',
                        letterSpacing: '0.06em',
                        whiteSpace:    'nowrap',
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredApplications.map((app) => (
                  <TableRow key={app._id} application={app} onClick={openDetail} />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Detail modal ───────────────────────────────────────────── */}
      <ApplicationDetailModal
        application={selected}
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onWithdraw={handleWithdraw}
      />
    </div>
  );
};

export default StudentApplicationsPage;
