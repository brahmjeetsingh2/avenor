import React, { useState, useEffect } from 'react';
import api from '../../services/api';

const StudentAIPrepPage = ({ embedded = false }) => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterType, setFilterType] = useState(''); // 'interview_prep', 'mock_interview', ''
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [selectedItem, setSelectedItem] = useState(null);

  const limit = 10;

  // Fetch AI history
  const fetchHistory = async (pageNum) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: pageNum,
        limit,
        ...(filterType && { type: filterType }),
      });

      const response = await api.get(`/ai/history?${params}`);
      const payload = response.data?.data || {};
      setHistory(payload.history || []);
      setTotal(response.data?.pagination?.total || 0);
      setPage(pageNum);
    } catch (err) {
      console.error('Failed to fetch history:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setPage(1);
    fetchHistory(1);
  }, [filterType]);

  // Handle feedback
  const handleFeedback = async (historyId, isHelpful) => {
    try {
      await api.patch(`/ai/history/${historyId}/feedback`, { isHelpful });

      // Update local state
      setHistory(prev =>
        prev.map(h => (h._id === historyId ? { ...h, isHelpful } : h))
      );

      if (selectedItem?._id === historyId) {
        setSelectedItem(prev => ({ ...prev, isHelpful }));
      }
    } catch (err) {
      console.error('Failed to submit feedback:', err);
    }
  };

  const pages = Math.ceil(total / limit);

  const getTypeLabel = (type) => {
    switch (type) {
      case 'interview_prep':
        return '📚 Interview Prep';
      case 'mock_interview':
        return '🎤 Mock Interview';
      case 'resume_feedback':
        return '📄 Resume Feedback';
      default:
        return type;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'interview_prep':
        return 'bg-[var(--role-cyan-tint)] text-[var(--role-cyan)] border border-[rgba(90,169,230,0.22)]';
      case 'mock_interview':
        return 'bg-[var(--role-magenta-tint)] text-[var(--role-magenta)] border border-[rgba(255,99,146,0.22)]';
      case 'resume_feedback':
        return 'bg-[var(--role-coral-tint)] text-[var(--role-coral)] border border-[rgba(255, 99, 146, 0.22)]';
      default:
        return 'bg-[var(--surface-2)] text-[var(--text-secondary)] border border-[var(--border)]';
    }
  };

  return (
    <div className={embedded ? '' : 'min-h-screen bg-[linear-gradient(135deg,var(--bg),var(--surface-2))] p-6'}>
      <div className={embedded ? '' : 'max-w-6xl mx-auto'}>
        {/* Header */}
        {!embedded && (
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-[var(--text-primary)] mb-2">
              AI Prep History
            </h1>
            <p className="text-[var(--text-secondary)]">
              Track your interview prep sessions, mock interviews, and AI-generated insights
            </p>
          </div>
        )}

        {/* Filter Section */}
        <div className="card p-6 mb-8">
          <div className="flex gap-4 flex-wrap items-center">
            <div className="flex gap-2">
              <button
                onClick={() => setFilterType('')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  filterType === ''
                    ? 'bg-[var(--role-cyan)] text-[var(--text-reverse)] shadow-[var(--btn-shadow-cyan)]'
                    : 'bg-[var(--surface-2)] text-[var(--text-secondary)] hover:bg-[var(--surface-3)] border border-[var(--border)]'
                }`}
              >
                All Activities
              </button>
              <button
                onClick={() => setFilterType('interview_prep')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  filterType === 'interview_prep'
                    ? 'bg-[var(--role-cyan)] text-[var(--text-reverse)] shadow-[var(--btn-shadow-cyan)]'
                    : 'bg-[var(--surface-2)] text-[var(--text-secondary)] hover:bg-[var(--surface-3)] border border-[var(--border)]'
                }`}
              >
                📚 Interview Prep
              </button>
              <button
                onClick={() => setFilterType('mock_interview')}
                className={`px-4 py-2 rounded-lg font-medium transition ${
                  filterType === 'mock_interview'
                    ? 'bg-[var(--role-cyan)] text-[var(--text-reverse)] shadow-[var(--btn-shadow-cyan)]'
                    : 'bg-[var(--surface-2)] text-[var(--text-secondary)] hover:bg-[var(--surface-3)] border border-[var(--border)]'
                }`}
              >
                🎤 Mock Interview
              </button>
            </div>
            <div className="ml-auto text-sm text-[var(--text-muted)]">
              {total} activities recorded
            </div>
          </div>
        </div>

        {/* History List & Detail View */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: History List */}
          <div className="lg:col-span-1">
            {loading ? (
              <div className="card p-6 text-center">
                <p className="text-[var(--text-secondary)]">Loading...</p>
              </div>
            ) : history.length === 0 ? (
              <div className="card p-6 text-center">
                <p className="text-[var(--text-secondary)]">No activities yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {history.map((item) => (
                  <button
                    key={item._id}
                    onClick={() => setSelectedItem(item)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition ${
                      selectedItem?._id === item._id
                        ? 'border-[var(--role-cyan)] bg-[var(--role-cyan-tint)]'
                        : 'border-[var(--border)] bg-[var(--surface)] hover:border-[var(--border-strong)]'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="text-2xl text-[var(--text-muted)]">
                        {item.type === 'interview_prep' && '📚'}
                        {item.type === 'mock_interview' && '🎤'}
                        {item.type === 'resume_feedback' && '📄'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-[var(--text-primary)] truncate">
                          {item.role}
                        </h3>
                        <p className="text-xs text-[var(--text-secondary)] truncate">
                          {item.company?.name}
                        </p>
                        <p className="text-xs text-[var(--text-muted)] mt-1">
                          {new Date(item.createdAt).toLocaleDateString()}
                        </p>
                        {item.performanceScore !== null && (
                          <p className="text-xs font-semibold text-[var(--role-magenta)] mt-1">
                            Score: {item.performanceScore}%
                          </p>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Pagination */}
            {pages > 1 && (
              <div className="flex justify-center gap-2 mt-4">
                <button
                  onClick={() => fetchHistory(Math.max(1, page - 1))}
                  disabled={page === 1}
                  className="px-3 py-2 rounded border border-[var(--border)] disabled:opacity-50 hover:bg-[var(--surface-2)] transition text-sm"
                >
                  ←
                </button>
                <span className="px-3 py-2 text-sm text-[var(--text-muted)]">
                  {page} of {pages}
                </span>
                <button
                  onClick={() => fetchHistory(Math.min(pages, page + 1))}
                  disabled={page === pages}
                  className="px-3 py-2 rounded border border-[var(--border)] disabled:opacity-50 hover:bg-[var(--surface-2)] transition text-sm"
                >
                  →
                </button>
              </div>
            )}
          </div>

          {/* Right: Detail View */}
          {selectedItem ? (
            <div className="lg:col-span-2 space-y-6">
              {/* Header Card */}
              <div className="card p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getTypeColor(selectedItem.type)}`}>
                      {getTypeLabel(selectedItem.type)}
                    </span>
                  </div>
                  <div className="text-right text-sm text-[var(--text-muted)]">
                    {new Date(selectedItem.createdAt).toLocaleDateString()} at{' '}
                    {new Date(selectedItem.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-[var(--text-primary)] mb-1">
                  {selectedItem.role}
                </h2>
                <p className="text-[var(--text-secondary)]">{selectedItem.company?.name}</p>

                {selectedItem.performanceScore !== null && (
                  <div className="mt-4 p-4 bg-[var(--role-magenta-tint)] rounded-lg border border-[rgba(255,99,146,0.22)]">
                    <p className="text-sm text-[var(--text-secondary)] mb-2">Performance Score</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-[var(--surface-3)] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[var(--role-magenta)]"
                          style={{ width: `${selectedItem.performanceScore}%` }}
                        ></div>
                      </div>
                      <span className="text-lg font-bold text-[var(--role-magenta)]">
                        {selectedItem.performanceScore}%
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Key Takeaways */}
              {selectedItem.keyTakeaways?.length > 0 && (
                <div className="card p-6">
                  <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">Key Takeaways</h3>
                  <ul className="space-y-2">
                    {selectedItem.keyTakeaways.map((takeaway, idx) => (
                      <li key={idx} className="flex gap-3">
                        <span className="text-[var(--role-cyan)] font-bold">✓</span>
                        <span className="text-[var(--text-secondary)]">{takeaway}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Questions Asked (Mock Interviews) */}
              {selectedItem.questionsAsked?.length > 0 && (
                <div className="card p-6">
                  <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">Questions Asked</h3>
                  <ol className="space-y-2 list-decimal list-inside">
                    {selectedItem.questionsAsked.map((q, idx) => (
                      <li key={idx} className="text-[var(--text-secondary)]">{q}</li>
                    ))}
                  </ol>
                </div>
              )}

              {/* Notes */}
              {selectedItem.notes && (
                <div className="card p-6">
                  <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">Notes</h3>
                  <p className="text-[var(--text-secondary)] whitespace-pre-wrap">{selectedItem.notes}</p>
                </div>
              )}

              {/* Prep Content */}
              {selectedItem.prepContent && (
                <div className="card p-6">
                  <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">Generated Content</h3>
                  <div className="prose prose-sm max-w-none">
                    <p className="text-[var(--text-secondary)] whitespace-pre-wrap text-sm">
                      {selectedItem.prepContent.slice(0, 1000)}
                      {selectedItem.prepContent.length > 1000 && '...'}
                    </p>
                  </div>
                </div>
              )}

              {/* Feedback Section */}
              <div className="card p-6">
                <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4">Was this helpful?</h3>
                <div className="flex gap-3">
                  <button
                    onClick={() => handleFeedback(selectedItem._id, true)}
                    className={`px-4 py-2 rounded-lg font-medium transition ${
                      selectedItem.isHelpful === true
                        ? 'bg-[var(--role-coral)] text-[var(--text-reverse)] shadow-[var(--btn-shadow-coral)]'
                        : 'bg-[var(--surface-2)] text-[var(--text-secondary)] hover:bg-[var(--surface-3)] border border-[var(--border)]'
                    }`}
                  >
                    👍 Yes, very helpful
                  </button>
                  <button
                    onClick={() => handleFeedback(selectedItem._id, false)}
                    className={`px-4 py-2 rounded-lg font-medium transition ${
                      selectedItem.isHelpful === false
                        ? 'bg-[var(--role-coral)] text-[var(--text-reverse)] shadow-[var(--btn-shadow-coral)]'
                        : 'bg-[var(--surface-2)] text-[var(--text-secondary)] hover:bg-[var(--surface-3)] border border-[var(--border)]'
                    }`}
                  >
                    👎 Not helpful
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="lg:col-span-2 card p-8 text-center">
              <p className="text-[var(--text-secondary)] text-lg">
                Select an item to view details
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentAIPrepPage;
