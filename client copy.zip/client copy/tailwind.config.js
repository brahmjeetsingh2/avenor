/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // ── Primary role families ───────────────────────────────────
        cyan: {
          50: '#F9F9F9',
          100: '#7FC8F8',
          200: '#7FC8F8',
          400: '#7FC8F8',
          500: '#5AA9E6',
          600: '#5AA9E6',
          700: '#020122',
        },
        coral: {
          50: '#FFE45E',
          100: '#F9C80E',
          200: '#F86624',
          400: '#F86624',
          500: '#EA3546',
          600: '#EA3546',
          700: '#020122',
        },
        lime: {
          50: '#F9F9F9',
          100: '#F9F9F9',
          200: '#F86624',
          400: '#F86624',
          500: '#F86624',
          600: '#EA3546',
          700: '#EA3546',
        },
        gold: {
          50: '#FFE45E',
          100: '#FFE45E',
          200: '#F9C80E',
          400: '#F9C80E',
          500: '#F9C80E',
          600: '#F86624',
          700: '#EA3546',
        },
        magenta: {
          50: '#FF6392',
          100: '#FF6392',
          200: '#FF6392',
          400: '#FF6392',
          500: '#FF6392',
          600: '#EA3546',
          700: '#020122',
        },

        // ── Accent aliases (backward compatible) ───────────────────
        accent: {
          DEFAULT: '#5AA9E6',
          400: '#7FC8F8',
          500: '#5AA9E6',
          600: '#020122',
          hover: '#020122',
          'hover-dark': '#7FC8F8',
          muted: 'rgba(90, 169, 230, 0.16)',
        },

        // ── Semantic status colors ────────────────────────────────────
        success: {
          DEFAULT: '#F86624',
          400: '#F86624',
          500: '#F86624',
          600: '#EA3546',
          light: '#F86624',
          muted: 'rgba(248, 102, 36, 0.15)',
        },
        warning: {
          DEFAULT: '#F9C80E',
          400: '#FFE45E',
          500: '#F9C80E',
          600: '#F86624',
          light: '#FFE45E',
          muted: 'rgba(249, 200, 14, 0.16)',
        },
        danger: {
          DEFAULT: '#EA3546',
          400: '#F86624',
          500: '#EA3546',
          600: '#EA3546',
          light: '#F86624',
          muted: 'rgba(234, 53, 70, 0.16)',
        },
        info: {
          DEFAULT: '#5AA9E6',
          500: '#5AA9E6',
          600: '#020122',
          light: '#7FC8F8',
        },

        // ── Dark surfaces ─────────────────────────────────────────────
        dark: {
          bg: '#020122',
          surface: '#141412',
          surface2: '#1C1C19',
          surface3: '#242420',
          border: '#2E2E2A',
        },

        // ── Light surfaces ────────────────────────────────────────────
        light: {
          bg: '#F9F9F9',
          surface: '#FFFFFF',
          surface2: '#F9F9F9',
          surface3: '#7FC8F8',
          border: '#7FC8F8',
        },

        // ── Legacy aliases (keeps all existing Tailwind class refs working) ──
        primary: {
          50: '#F9F9F9',
          100: '#7FC8F8',
          200: '#7FC8F8',
          300: '#5AA9E6',
          400: '#5AA9E6',
          500: '#5AA9E6',
          600: '#020122',
          700: '#020122',
          800: '#020122',
          900: '#020122',
          950: '#020122',
        },
      },

      fontFamily: {
        // Primary text stack — matches body CSS variable
        sans: [
          '"DM Sans"',
          'sans-serif',
        ],
        // Display / headings stack
        display: [
          '"Space Grotesk"',
          'sans-serif',
        ],
        mono: ['"Geist Mono"', '"JetBrains Mono"', 'monospace'],
      },

      fontSize: {
        // HireTrack type scale
        'display': ['clamp(48px, 6vw, 72px)', { lineHeight: '1.02', letterSpacing: '-0.04em' }],
        'h1':      ['clamp(36px, 4vw, 48px)',  { lineHeight: '1.08', letterSpacing: '-0.04em'  }],
        'h2':      ['clamp(24px, 3vw, 32px)',  { lineHeight: '1.12', letterSpacing: '-0.035em' }],
        'h3':      ['clamp(18px, 2vw, 24px)',  { lineHeight: '1.2',  letterSpacing: '-0.01em'  }],
        'body-lg': ['18px', { lineHeight: '1.6' }],
        'body':    ['16px', { lineHeight: '1.6' }],
        'small':   ['13px', { lineHeight: '1.4' }],
      },

      borderRadius: {
        'card':  '16px',
        'panel': '24px',
        'input': '12px',
        'pill':  '999px',
      },

      spacing: {
        // 8px grid system
        'xs':  '4px',
        'sm':  '8px',
        'md':  '16px',
        'lg':  '24px',
        'xl':  '32px',
        '2xl': '48px',
        '3xl': '64px',
      },

      maxWidth: {
        'content': '1280px',
      },

      backdropBlur: {
        'nav': '20px',
      },

      boxShadow: {
        'soft': '0 1px 3px rgba(0, 0, 0, 0.08), 0 4px 16px rgba(0, 0, 0, 0.06)',
        'hover': '0 4px 24px rgba(0, 0, 0, 0.10)',
        'soft-dark': '0 4px 16px rgba(0, 0, 0, 0.60), 0 0 0 1px #2E2E2A',
        'hover-dark': '0 8px 28px rgba(0, 0, 0, 0.72), 0 0 0 1px #3C3C36',
        // Legacy aliases
        'glow-sm': '0 0 15px rgba(90, 169, 230, 0.22)',
        'glow-md': '0 0 30px rgba(90, 169, 230, 0.3)',
        'glow-lg': '0 0 60px rgba(90, 169, 230, 0.25)',
        'card-dark':  '0 4px 24px rgba(0,0,0,0.4)',
        'card-light': '0 4px 24px rgba(0,0,0,0.08)',
      },

      transitionTimingFunction: {
        'apple': 'cubic-bezier(0.2, 0.8, 0.2, 1)',
      },

      transitionDuration: {
        'fast':   '180ms',
        'normal': '220ms',
      },

      animation: {
        'fade-in':    'fadeIn 0.35s cubic-bezier(0.2, 0.8, 0.2, 1) both',
        'slide-up':   'slideUp 0.35s cubic-bezier(0.2, 0.8, 0.2, 1) both',
        'slide-down': 'slideDown 0.25s cubic-bezier(0.2, 0.8, 0.2, 1) both',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'float':      'float 6s ease-in-out infinite',
        'shimmer':    'shimmer 1.8s linear infinite',
        'pulse-ring': 'pulse-ring 1.5s ease-out infinite',
      },

      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%':   { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%':   { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%':       { transform: 'translateY(-10px)' },
        },
        shimmer: {
          '0%':   { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition:  '200% 0' },
        },
        'pulse-ring': {
          '0%':   { transform: 'scale(1)', opacity: '1' },
          '100%': { transform: 'scale(1.6)', opacity: '0' },
        },
      },

      backgroundImage: {
        // Kept for landing page / hero compatibility
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'hero-gradient': 'linear-gradient(135deg, #020122 0%, #141412 50%, #1C1C19 100%)',
        'card-gradient': 'linear-gradient(135deg, rgba(90,169,230,0.12) 0%, rgba(255, 99, 146, 0.04) 100%)',
        'glow-primary': 'radial-gradient(ellipse at center, rgba(90,169,230,0.2) 0%, transparent 70%)',
      },
    },
  },
  plugins: [],
}